#include "RIS_Ricean.h"

RIS_Ricean::RIS_Ricean(const int in_BPS, const int in_M_RIS)
{
	BPS = in_BPS;
	M_RIS = in_M_RIS;

	constellation_points = (int) pow2(BPS);
	modulation_type = MPSK;
	Set_Modulation();
}

RIS_Ricean::RIS_Ricean(const int in_BPS, const int in_M_RIS, const QAM_Type in_qam_type)
{
	BPS = in_BPS;
	M_RIS = in_M_RIS;

	constellation_points = (int) pow2(BPS);
	modulation_type = MQAM;
	qam_type = in_qam_type;
	Set_Modulation();
}

RIS_Ricean::RIS_Ricean(const int in_BPS, const int in_M_RIS, const int in_constellation_points_A, const double in_alpha)
{
	BPS = in_BPS;
	M_RIS = in_M_RIS;
	modulation_type = MQAM;
	qam_type = Star;
	alpha = in_alpha;
	constellation_points = (int) pow2(BPS);
	constellation_points_A = in_constellation_points_A;
	BPS_A = (int) log2(constellation_points_A);
	BPS_P = BPS - BPS_A;
	constellation_points_P = (int) pow2(BPS_P);
	Set_Modulation();
}

void RIS_Ricean::Set_Location(const vec in_coordinate_S, const vec in_coordinate_R, const vec in_coordinate_D)
{
	coordinate_S = in_coordinate_S;
	coordinate_R = in_coordinate_R;
	coordinate_D = in_coordinate_D;
}

void RIS_Ricean::Set_Freq(const double in_f_c, const double in_f_s, const double in_v_speed)
{
	f_c = in_f_c;
	f_s = in_f_s;
	v_speed = in_v_speed;

	fd_SD = v_speed*f_c/(3e8*f_s);
	fd_SR = 1e-10;
	fd_RD = fd_SD;

	lambda_c = 3e8/f_c;
}

void RIS_Ricean::Set_K_Ricean(const double in_K_SD_dB, const double in_K_SR_dB, const double in_K_RD_dB)
{
	K_SD_dB = in_K_SD_dB;
	K_SR_dB = in_K_SR_dB;
	K_RD_dB = in_K_RD_dB;

	K_SD = inv_dB(K_SD_dB);
	K_SR = inv_dB(K_SR_dB);
	K_RD = inv_dB(K_RD_dB);
}

void RIS_Ricean::Set_Modulation()
{
	j = complex<double>(0.0,1.0);

	Symbol_Mapping_Bin.set_size(constellation_points, BPS, false);
	Symbol_Set.set_size(constellation_points, false);
	Symbol_Set_rotate.set_size(constellation_points, false);

	Symbol_Mapping_Bin_Magn.set_size(1, 0, false);
	Symbol_Mapping_Bin_Magn_real.set_size(1, 0, false);
	Symbol_Mapping_Bin_Magn_imag.set_size(1, 0, false);
	a_i_real.set_size(1, false);
	a_i_imag.set_size(1, false);
	a_i.set_size(1, false);

	Symbol_Mapping_Bin_A.set_size(1, 0, false);
	Symbol_Mapping_Bin_P.set_size(1, 0, false);
	Amplitude_Set.set_size(1, false);
	Phase_Set.set_size(1, false);
	Phase_Set_rotate.set_size(1, false);

	for(int point_ct=0; point_ct<constellation_points; point_ct++) {
		bvec bin_temp = dec2bin(point_ct);
		if(bin_temp.length()<BPS)
			Symbol_Mapping_Bin.set_row(point_ct,concat(zeros_b((BPS)-bin_temp.length()),bin_temp));
		else
			Symbol_Mapping_Bin.set_row(point_ct,bin_temp);
	}

	if(modulation_type == MPSK) {
		//Symbol set for PSK modulation
		psk.set_M(constellation_points);
		phase_rotate = complex<double>(1.0,0.0);
		if(BPS>1)
			phase_rotate = exp(j*pi/constellation_points);
		for(int point_ct=0; point_ct<constellation_points; point_ct++) {
			cvec symbol = psk.modulate_bits(Symbol_Mapping_Bin.get_row(point_ct));
			Symbol_Set(point_ct) = symbol(0);
			Symbol_Set_rotate(point_ct) = Symbol_Set(point_ct)*phase_rotate;
		}

		if(BPS<=2) {
			a_i_length = 1;
			a_i_real.set_size(a_i_length, false);
			a_i_imag.set_size(a_i_length, false);
			a_i_real(0) = real(Symbol_Set_rotate(0));
			a_i_imag(0) = imag(Symbol_Set_rotate(0));
		} else {
			a_i_length = constellation_points/4;
			a_i_real = real(Symbol_Set_rotate.left(a_i_length));
			a_i_imag = imag(Symbol_Set_rotate.left(a_i_length));
			Symbol_Mapping_Bin_Magn.set_size(a_i_length, BPS-2, false);
			for(int row_ct=0; row_ct<a_i_length; row_ct++) {
				bvec bin_temp = dec2bin(row_ct);
				if(bin_temp.length()<(BPS-2))
					Symbol_Mapping_Bin_Magn.set_row(row_ct,concat(zeros_b(BPS-2-bin_temp.length()),bin_temp));
				else
					Symbol_Mapping_Bin_Magn.set_row(row_ct,bin_temp);
			}
		}
cout<<sum(sqr(abs(Symbol_Set)))/constellation_points<<endl;
	} else if(modulation_type == MQAM) {
		if(qam_type==Square) {
			if(mod(BPS,2)==0) {
				constellation_points_QAM_real = sqrt(constellation_points);
				constellation_points_QAM_imag = constellation_points_QAM_real;

				qam.set_M(constellation_points);
				for(int point_ct=0; point_ct<constellation_points; point_ct++) {
					cvec symbol_temp = qam.modulate_bits(Symbol_Mapping_Bin.get_row(point_ct));
					Symbol_Set(point_ct) = symbol_temp(0);
				}

				a_i_length = constellation_points_QAM_real/2;
				a_i=ones(a_i_length);
				for(int a_i_ct=1; a_i_ct<a_i_length; a_i_ct++)
					a_i(a_i_ct)=a_i(a_i_ct-1)+2;
				double test_a=0.0;
				for(int i_ct=0; i_ct<a_i_length; i_ct++) {
					for(int j_ct=0; j_ct<a_i_length; j_ct++) {
						test_a+=(sqr(a_i(i_ct))+sqr(a_i(j_ct)));
					}
				}
				beta = test_a/(constellation_points/4.0);
				beta_sqrt = sqrt(beta);
				a_i = a_i/beta_sqrt;

				bmat Symbol_Mapping_Bin_Magn_temp = graycode(BPS/2-1);
				Symbol_Mapping_Bin_Magn.set_size(a_i_length,BPS/2-1);
				for(int row_ct=0; row_ct<a_i_length; row_ct++)
					Symbol_Mapping_Bin_Magn.set_row(row_ct,Symbol_Mapping_Bin_Magn_temp.get_row(a_i_length-1-row_ct));
cout<<Symbol_Set*beta_sqrt<<endl;
cout<<sum(sqr(abs(Symbol_Set)))/constellation_points<<endl;
			} else {
				constellation_points_QAM_real = (int) pow2((BPS+1)/2);
				constellation_points_QAM_imag = (int) pow2((BPS-1)/2);

				a_i_length_real = constellation_points_QAM_real/2;
				a_i_length_imag = constellation_points_QAM_imag/2;
				qam_real.set_M(constellation_points_QAM_real);
				qam_imag.set_M(constellation_points_QAM_imag);

				a_i_real=ones(a_i_length_real);
				for(int a_i_real_ct=1; a_i_real_ct<a_i_length_real; a_i_real_ct++)
					a_i_real(a_i_real_ct)=a_i_real(a_i_real_ct-1)+2;
				a_i_imag=ones(a_i_length_imag);
				for(int a_i_imag_ct=1; a_i_imag_ct<a_i_length_imag; a_i_imag_ct++)
					a_i_imag(a_i_imag_ct)=a_i_imag(a_i_imag_ct-1)+2;
				double test_real=0.0, test_imag=0.0;
				for(int i_ct=0; i_ct<a_i_length_real; i_ct++)
					test_real+=sqr(a_i_real(i_ct));
				for(int j_ct=0; j_ct<a_i_length_imag; j_ct++)
					test_imag+=sqr(a_i_imag(j_ct));
				test_real = test_real/a_i_length_real;
				test_imag = test_imag/a_i_length_imag;
				double test_a=0.0;
				for(int i_ct=0; i_ct<a_i_length_real; i_ct++) {
					for(int j_ct=0; j_ct<a_i_length_imag; j_ct++) {
						test_a+=(sqr(a_i_real(i_ct))+sqr(a_i_imag(j_ct)));
					}
				}
				test_a = test_a/(constellation_points/4);
				beta = test_a;
				beta_sqrt = sqrt(beta);

				for(int point_ct=0; point_ct<constellation_points; point_ct++) {
					bvec bin_temp = Symbol_Mapping_Bin.get_row(point_ct);
					cvec symbol_temp = sqrt(1/test_a)*(sqrt(test_real)*qam_real.modulate_bits(bin_temp.right((BPS+1)/2))+sqrt(test_imag)*j*qam_imag.modulate_bits(bin_temp.left((BPS-1)/2)));
					Symbol_Set(point_ct) = symbol_temp(0);
				}
				a_i_real = sqrt(1/test_a)*a_i_real;
				a_i_imag = sqrt(1/test_a)*a_i_imag;

				bmat Symbol_Mapping_Bin_temp_real = graycode((BPS+1)/2-1);
				bmat Symbol_Mapping_Bin_temp_imag = graycode((BPS-1)/2-1);
				Symbol_Mapping_Bin_Magn_real.set_size(a_i_length_real,(BPS+1)/2-1);
				Symbol_Mapping_Bin_Magn_imag.set_size(a_i_length_imag,(BPS-1)/2-1);
				for(int row_ct=0; row_ct<a_i_length_real; row_ct++)
					Symbol_Mapping_Bin_Magn_real.set_row(row_ct,Symbol_Mapping_Bin_temp_real.get_row(a_i_length_real-1-row_ct));

				for(int row_ct=0; row_ct<a_i_length_imag; row_ct++)
					Symbol_Mapping_Bin_Magn_imag.set_row(row_ct,Symbol_Mapping_Bin_temp_imag.get_row(a_i_length_imag-1-row_ct));

cout<<Symbol_Set*beta_sqrt<<endl;
cout<<sum(sqr(abs(Symbol_Set)))/constellation_points<<endl;
			}
		} else if(qam_type==Star) {
			//Normalization factor
			beta = 1.0;
			for(int a_ct=1; a_ct<constellation_points_A; a_ct++) {
				beta += pow(alpha,2*a_ct);
			}
			beta = beta/constellation_points_A;
			beta_sqrt = sqrt(beta);

			Symbol_Mapping_Bin_A.set_size(constellation_points_A, BPS_A, false);
			for(int row_ct=0; row_ct<constellation_points_A; row_ct++) {
				bvec bin_temp = dec2bin(row_ct);
				if(bin_temp.length()<BPS_A)
					Symbol_Mapping_Bin_A.set_row(row_ct,concat(zeros_b(BPS_A-bin_temp.length()),bin_temp));
				else
					Symbol_Mapping_Bin_A.set_row(row_ct,bin_temp);
			}
			Symbol_Mapping_Bin_P.set_size(constellation_points_P, BPS_P, false);
			for(int row_ct=0; row_ct<constellation_points_P; row_ct++) {
				bvec bin_temp = dec2bin(row_ct);
				if(bin_temp.length()<BPS_P)
					Symbol_Mapping_Bin_P.set_row(row_ct,concat(zeros_b(BPS_P-bin_temp.length()),bin_temp));
				else
					Symbol_Mapping_Bin_P.set_row(row_ct,bin_temp);
			}

			Amplitude_Set.set_size(constellation_points_A);
			Phase_Set.set_size(constellation_points_P);
			Phase_Set_rotate.set_size(constellation_points_P);
			psk.set_M(constellation_points_P);

			bmat Amplitude_Gray = graycode(BPS_A);
			for(int a_ct=0; a_ct<constellation_points_A; a_ct++)
				Amplitude_Set(a_ct) = pow(alpha,bin2dec(Amplitude_Gray.get_row(a_ct)))/sqrt(beta);

			phase_rotate = complex<double>(1.0,0.0);
			if(BPS_P>1)
				phase_rotate = exp(j*pi/constellation_points_P);
			for(int phase_point=0; phase_point<constellation_points_P; phase_point++) {
				bvec bin_temp = Symbol_Mapping_Bin_P.get_row(phase_point);
				cvec symbol_temp = psk.modulate_bits(bin_temp);
				Phase_Set(phase_point) = symbol_temp(0);
				Phase_Set_rotate(phase_point) = Phase_Set(phase_point)*phase_rotate;
			}

			for(int point_ct=0; point_ct<constellation_points; point_ct++) {
				bvec bin_temp = Symbol_Mapping_Bin.get_row(point_ct);
				int amp_index = bin2dec(bin_temp.right(BPS_A)), phase_index = bin2dec(bin_temp.left(BPS_P));
				Symbol_Set(point_ct) = Amplitude_Set(amp_index)*Phase_Set(phase_index);
				Symbol_Set_rotate(point_ct) = Amplitude_Set(amp_index)*Phase_Set_rotate(phase_index);
			}

			a_i_length = constellation_points/4;
			a_i_real = real(Symbol_Set_rotate.left(a_i_length));
			a_i_imag = imag(Symbol_Set_rotate.left(a_i_length));

			Symbol_Mapping_Bin_Magn.set_size(a_i_length, BPS-2, false);
			for(int row_ct=0; row_ct<a_i_length; row_ct++) {
				bvec bin_temp = dec2bin(row_ct);
				if(bin_temp.length()<(BPS-2))
					Symbol_Mapping_Bin_Magn.set_row(row_ct,concat(zeros_b(BPS-2-bin_temp.length()),bin_temp));
				else
					Symbol_Mapping_Bin_Magn.set_row(row_ct,bin_temp);
			}
cout<<sum(sqr(abs(Symbol_Set)))/constellation_points<<endl;
		}
	}

	DFT_Matrix.set_size(M_RIS+1,M_RIS+1);
	for(int row_ct=0; row_ct<=M_RIS; row_ct++) {
		for(int col_ct=0; col_ct<=M_RIS; col_ct++) {
			DFT_Matrix(row_ct,col_ct) = exp(-j*2.0*pi*row_ct*col_ct/(M_RIS+1));
		}
	}
	DFT_Matrix_inv = inv(DFT_Matrix);
}

void RIS_Ricean::Set_PL(const double in_gamma_SD, const double in_gamma_SR, const double in_gamma_RD, const double in_Gain_BF_dB, const double in_PL0_dB)
{
	gamma_SD = in_gamma_SD;
	gamma_SR = in_gamma_SR;
	gamma_RD = in_gamma_RD;
	Gain_BF_dB = in_Gain_BF_dB;
	PL0_dB = in_PL0_dB;
}

void RIS_Ricean::Display_Gamma()
{
double d_SD0 = sqrt(sqr(coordinate_D(0)-coordinate_S(0))+sqr(coordinate_D(1)-coordinate_S(1))+sqr(coordinate_D(2)-coordinate_S(2)));
double Gamma_SD0 = pow(d_SD0,-1.0*gamma_SD)*inv_dB(Gain_BF_dB)*inv_dB(PL0_dB);
cout<<"Gamma_SD0="<<Gamma_SD0<<endl;


double d_SR0 = sqrt(sqr(coordinate_R(0)-coordinate_S(0))+sqr(coordinate_R(1)-coordinate_S(1))+sqr(coordinate_R(2)-coordinate_S(2)));
double Gamma_SR0 = pow(d_SR0,-1.0*gamma_SR)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
cout<<"Gamma_SR0="<<Gamma_SR0<<endl;

double d_RD0 = sqrt(sqr(coordinate_R(0)-coordinate_D(0))+sqr(coordinate_R(1)-coordinate_D(1))+sqr(coordinate_R(2)-coordinate_D(2)));
double Gamma_RD0 = pow(d_RD0,-1.0*gamma_RD)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
cout<<"Gamma_RD0="<<Gamma_RD0<<endl;

cout<<"Gamma_SRD0="<<Gamma_SR0*Gamma_RD0<<endl;
}

bvec RIS_Ricean::RIS_Ricean_Perfect_CSI(const bvec b, const double N0)
{
	int data_bits = b.length(), data_symbols = data_bits/BPS;
	bvec b_hat(data_bits);

	//source encoding
	cvec s_tx = ones_c(data_symbols);
	for(int symbol_ct=0; symbol_ct<data_symbols; symbol_ct++)
		s_tx(symbol_ct) = Symbol_Set(bin2dec(b.mid(symbol_ct*BPS,BPS)));

	//update coordinate
	vec coordinate_D_x(data_symbols);
	coordinate_D_x(0) = coordinate_D(0);
	for(int symbol_ct=1; symbol_ct<data_symbols; symbol_ct++)
		coordinate_D_x(symbol_ct) = coordinate_D_x(symbol_ct-1) - v_speed/f_s;

	//generate source-destination
	cvec h_SD(data_symbols), h_SD_LoS(data_symbols);
	TDL_Channel Rayleigh_SD;
	Rayleigh_SD.set_norm_doppler(fd_SD);
	cmat channel_SD;
	Rayleigh_SD.generate(data_symbols, channel_SD);
	cvec rayleigh_channels_SD = channel_SD.get_col(0);
	for(int symbol_ct=0; symbol_ct<data_symbols; symbol_ct++) {
		//update large scale
		double d_SD = sqrt(sqr(coordinate_D_x(symbol_ct)-coordinate_S(0))+sqr(coordinate_D(1)-coordinate_S(1))+sqr(coordinate_D(2)-coordinate_S(2)));
		double Gamma_SD = pow(d_SD,-1.0*gamma_SD)*inv_dB(Gain_BF_dB)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_D(1)-coordinate_S(1))/(coordinate_D_x(symbol_ct)-coordinate_S(0)));
		h_SD_LoS(symbol_ct) = sqrt(Gamma_SD*K_SD/(K_SD+1))*exp(j*2*pi*symbol_ct*fd_SD*cos(AoA_mov));
		h_SD(symbol_ct) = h_SD_LoS(symbol_ct) + sqrt(Gamma_SD/(K_SD+1))*rayleigh_channels_SD(symbol_ct);
	}

	//generate source-RIS
	cmat h_SR(M_RIS,data_symbols), h_SR_LoS(M_RIS,data_symbols);
	TDL_Channel Rayleigh_SR;
	cmat rayleigh_channels_SR(M_RIS,data_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_SR.set_norm_doppler(fd_SR);
		cmat channel_SR;
		Rayleigh_SR.generate(data_symbols, channel_SR);
		rayleigh_channels_SR.set_row(channel_ct,channel_SR.get_col(0));
	}
	int M_RIS_y = (int) sqrt(M_RIS), M_RIS_z = M_RIS/M_RIS_y;
	for(int symbol_ct=0; symbol_ct<data_symbols; symbol_ct++) {
		//update large scale
		double d_SR = sqrt(sqr(coordinate_R(0)-coordinate_S(0))+sqr(coordinate_R(1)-coordinate_S(1))+sqr(coordinate_R(2)-coordinate_S(2)));
		double Gamma_SR = pow(d_SR,-1.0*gamma_SR)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		//update AoA
		double theta = acos((coordinate_S(2)-coordinate_R(2))/d_SR);
		double phi = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_SR_LoS(m_ct,symbol_ct) = sqrt(Gamma_SR*K_SR/(K_SR+1))*exp(j*2*pi*symbol_ct*fd_SR*cos(AoA_mov))*exp(j*pi*(m_y*sin(theta)*cos(phi)+m_z*sin(phi)));
				h_SR(m_ct,symbol_ct) = h_SR_LoS(m_ct,symbol_ct) + sqrt(Gamma_SR/(K_SR+1))*rayleigh_channels_SR(m_ct,symbol_ct);
			}
		}
	}

	//generate RIS-destination
	cmat h_RD(M_RIS,data_symbols), h_RD_LoS(M_RIS,data_symbols), h_SRD(M_RIS,data_symbols), alpha_RIS(M_RIS,data_symbols);
	cvec h_equi=zeros_c(data_symbols), y_all(data_symbols), v_all = N0*randn_c(data_symbols);
	TDL_Channel Rayleigh_RD;
	cmat rayleigh_channels_RD(M_RIS,data_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_RD.set_norm_doppler(fd_RD);
		cmat channel_RD;
		Rayleigh_RD.generate(data_symbols, channel_RD);
		rayleigh_channels_RD.set_row(channel_ct,channel_RD.get_col(0));
	}
	for(int symbol_ct=0; symbol_ct<data_symbols; symbol_ct++) {
		//update large scale
		double d_RD = sqrt(sqr(coordinate_R(0)-coordinate_D_x(symbol_ct))+sqr(coordinate_R(1)-coordinate_D(1))+sqr(coordinate_R(2)-coordinate_D(2)));
		double Gamma_RD = pow(d_RD,-1.0*gamma_RD)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_D(1))/(coordinate_R(0)-coordinate_D_x(symbol_ct)));
		//update AoD
		double theta = acos((coordinate_D(2)-coordinate_R(2))/d_RD);
		double phi = atan((coordinate_D(1)-coordinate_R(1))/(coordinate_D_x(symbol_ct)-coordinate_R(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_RD_LoS(m_ct,symbol_ct) = sqrt(Gamma_RD*K_RD/(K_RD+1))*exp(j*2*pi*symbol_ct*fd_RD*cos(AoA_mov))*exp(-j*pi*(m_y*sin(theta)*cos(phi)-m_z*sin(phi)));
				h_RD(m_ct,symbol_ct) = h_RD_LoS(m_ct,symbol_ct) + sqrt(Gamma_RD/(K_RD+1))*rayleigh_channels_RD(m_ct,symbol_ct);
				h_SRD(m_ct,symbol_ct) = h_SR(m_ct,symbol_ct)*h_RD(m_ct,symbol_ct);
				alpha_RIS(m_ct,symbol_ct) = h_SD(symbol_ct)*conj(h_SRD(m_ct,symbol_ct))/(abs(h_SD(symbol_ct))*abs(h_SRD(m_ct,symbol_ct)));
				h_equi(symbol_ct) = h_equi(symbol_ct)+alpha_RIS(m_ct,symbol_ct)*h_SRD(m_ct,symbol_ct);
			}
		}
		h_equi(symbol_ct) = h_equi(symbol_ct) + h_SD(symbol_ct);
		y_all(symbol_ct) = h_equi(symbol_ct)*s_tx(symbol_ct) + v_all(symbol_ct);
		complex<double> z = y_all(symbol_ct)*conj(h_equi(symbol_ct))/sqr(abs(h_equi(symbol_ct)));
		int index_hat = PSK_QAM_Dem(z);
		for(int bit_ct=0; bit_ct<BPS; bit_ct++)
			b_hat(symbol_ct*BPS+bit_ct)=Symbol_Mapping_Bin(index_hat,bit_ct);
	}
//cout<<h_equi<<endl;
	return b_hat;	
}

bvec RIS_Ricean::RIS_Ricean_ONOFF_CSI(const bvec b, const double N0, const int N_f)
{
	int data_bits = b.length(), data_symbols = data_bits/BPS;
	bvec b_hat(data_bits);

	int data_symbols_f = N_f-(M_RIS+1), CSI_frames = data_symbols/data_symbols_f, total_symbols = N_f*CSI_frames;
//cout<<data_symbols<<" "<<data_symbols_f<<endl;
	//source encoding
	cvec s_tx = ones_c(total_symbols);
	for(int frame_ct=0; frame_ct<CSI_frames; frame_ct++) {
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++)
			s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) = Symbol_Set(bin2dec(b.mid(frame_ct*data_symbols_f*BPS+symbol_ct*BPS,BPS)));
	}

	//update coordinate
	vec coordinate_D_x(total_symbols);
	coordinate_D_x(0) = coordinate_D(0);
	for(int symbol_ct=1; symbol_ct<total_symbols; symbol_ct++)
		coordinate_D_x(symbol_ct) = coordinate_D_x(symbol_ct-1) - v_speed/f_s;

	//generate source-destination
	cvec h_SD(total_symbols), h_SD_LoS(total_symbols);
	TDL_Channel Rayleigh_SD;
	Rayleigh_SD.set_norm_doppler(fd_SD);
	cmat channel_SD;
	Rayleigh_SD.generate(total_symbols, channel_SD);
	cvec rayleigh_channels_SD = channel_SD.get_col(0);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SD = sqrt(sqr(coordinate_D_x(symbol_ct)-coordinate_S(0))+sqr(coordinate_D(1)-coordinate_S(1))+sqr(coordinate_D(2)-coordinate_S(2)));
		double Gamma_SD = pow(d_SD,-1.0*gamma_SD)*inv_dB(Gain_BF_dB)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_D(1)-coordinate_S(1))/(coordinate_D_x(symbol_ct)-coordinate_S(0)));
		h_SD_LoS(symbol_ct) = sqrt(Gamma_SD*K_SD/(K_SD+1))*exp(j*2*pi*symbol_ct*fd_SD*cos(AoA_mov));
		h_SD(symbol_ct) = h_SD_LoS(symbol_ct) + sqrt(Gamma_SD/(K_SD+1))*rayleigh_channels_SD(symbol_ct);
	}

	//generate source-RIS
	cmat h_SR(M_RIS,total_symbols), h_SR_LoS(M_RIS,total_symbols);
	TDL_Channel Rayleigh_SR;
	cmat rayleigh_channels_SR(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_SR.set_norm_doppler(fd_SR);
		cmat channel_SR;
		Rayleigh_SR.generate(total_symbols, channel_SR);
		rayleigh_channels_SR.set_row(channel_ct,channel_SR.get_col(0));
	}
	int M_RIS_y = (int) sqrt(M_RIS), M_RIS_z = M_RIS/M_RIS_y;
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SR = sqrt(sqr(coordinate_R(0)-coordinate_S(0))+sqr(coordinate_R(1)-coordinate_S(1))+sqr(coordinate_R(2)-coordinate_S(2)));
		double Gamma_SR = pow(d_SR,-1.0*gamma_SR)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		//update AoA
		double theta = acos((coordinate_S(2)-coordinate_R(2))/d_SR);
		double phi = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_SR_LoS(m_ct,symbol_ct) = sqrt(Gamma_SR*K_SR/(K_SR+1))*exp(j*2*pi*symbol_ct*fd_SR*cos(AoA_mov))*exp(j*pi*(m_y*sin(theta)*cos(phi)+m_z*sin(phi)));
				h_SR(m_ct,symbol_ct) = h_SR_LoS(m_ct,symbol_ct) + sqrt(Gamma_SR/(K_SR+1))*rayleigh_channels_SR(m_ct,symbol_ct);
			}
		}
	}

	//generate RIS-destination
	cmat h_RD(M_RIS,total_symbols), h_RD_LoS(M_RIS,total_symbols), h_SRD(M_RIS,total_symbols);
	TDL_Channel Rayleigh_RD;
	cmat rayleigh_channels_RD(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_RD.set_norm_doppler(fd_RD);
		cmat channel_RD;
		Rayleigh_RD.generate(total_symbols, channel_RD);
		rayleigh_channels_RD.set_row(channel_ct,channel_RD.get_col(0));
	}
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_RD = sqrt(sqr(coordinate_R(0)-coordinate_D_x(symbol_ct))+sqr(coordinate_R(1)-coordinate_D(1))+sqr(coordinate_R(2)-coordinate_D(2)));
		double Gamma_RD = pow(d_RD,-1.0*gamma_RD)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_D(1))/(coordinate_R(0)-coordinate_D_x(symbol_ct)));
		//update AoD
		double theta = acos((coordinate_D(2)-coordinate_R(2))/d_RD);
		double phi = atan((coordinate_D(1)-coordinate_R(1))/(coordinate_D_x(symbol_ct)-coordinate_R(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_RD_LoS(m_ct,symbol_ct) = sqrt(Gamma_RD*K_RD/(K_RD+1))*exp(j*2*pi*symbol_ct*fd_RD*cos(AoA_mov))*exp(-j*pi*(m_y*sin(theta)*cos(phi)-m_z*sin(phi)));
				h_RD(m_ct,symbol_ct) = h_RD_LoS(m_ct,symbol_ct) + sqrt(Gamma_RD/(K_RD+1))*rayleigh_channels_RD(m_ct,symbol_ct);
				h_SRD(m_ct,symbol_ct) = h_SR(m_ct,symbol_ct)*h_RD(m_ct,symbol_ct);
			}
		}
	}

	cvec h_equi=zeros_c(total_symbols), y_all(total_symbols), v_all = N0*randn_c(total_symbols);
	for(int frame_ct=0; frame_ct<CSI_frames; frame_ct++) {
		y_all(frame_ct*N_f) = h_SD(frame_ct*N_f) + v_all(frame_ct*N_f);
		complex<double> h_SD_hat = y_all(frame_ct*N_f);
		cvec h_SRD_hat(M_RIS), alpha_RIS(M_RIS);
		complex<double > h_equi_hat=complex<double>(0.0,0.0);
		for(int m_ct=0; m_ct<M_RIS; m_ct++) {
			y_all(frame_ct*N_f+1+m_ct) = h_SD(frame_ct*N_f+1+m_ct) + h_SRD(m_ct,frame_ct*N_f+1+m_ct) + v_all(frame_ct*N_f+1+m_ct);
			y_all(frame_ct*N_f+1+m_ct) = y_all(frame_ct*N_f+1+m_ct) - h_SD_hat;
			h_SRD_hat(m_ct) = y_all(frame_ct*N_f+1+m_ct);
			alpha_RIS(m_ct) = h_SD_hat*conj(h_SRD_hat(m_ct))/(abs(h_SD_hat)*abs(h_SRD_hat(m_ct)));
			h_equi_hat = h_equi_hat + alpha_RIS(m_ct)*h_SRD_hat(m_ct);
		}
		h_equi_hat = h_equi_hat + h_SD_hat;
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++) {
			for(int m_ct=0; m_ct<M_RIS; m_ct++)
				h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) = h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) + alpha_RIS(m_ct)*h_SRD(m_ct,frame_ct*N_f+M_RIS+1+symbol_ct);
			h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) = h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) + h_SD(frame_ct*N_f+M_RIS+1+symbol_ct);
			y_all(frame_ct*N_f+M_RIS+1+symbol_ct) = h_equi(frame_ct*N_f+M_RIS+1+symbol_ct)*s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) + v_all(frame_ct*N_f+M_RIS+1+symbol_ct);
			complex<double> z = y_all(frame_ct*N_f+M_RIS+1+symbol_ct)*conj(h_equi_hat)/sqr(abs(h_equi_hat));
			int index_hat = PSK_QAM_Dem(z);
			for(int bit_ct=0; bit_ct<BPS; bit_ct++)
				b_hat(frame_ct*data_symbols_f*BPS+symbol_ct*BPS+bit_ct)=Symbol_Mapping_Bin(index_hat,bit_ct);
		}
//cout<<h_equi.mid(frame_ct*N_f,N_f)<<" "<<h_equi_hat<<endl;
	}

	return b_hat;	
}

void RIS_Ricean::MSE_RIS_Ricean_ONOFF_CSI(const bvec b, const double N0, const int N_f, double &MSE_SD, double &MSE_SRD, double &MSE_AV)
{
	int data_bits = b.length(), data_symbols = data_bits/BPS;

	int data_symbols_f = N_f-(M_RIS+1), CSI_frames = data_symbols/data_symbols_f, total_symbols = N_f*CSI_frames;

	//source encoding
	cvec s_tx = ones_c(total_symbols);
	for(int frame_ct=0; frame_ct<CSI_frames; frame_ct++) {
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++)
			s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) = Symbol_Set(bin2dec(b.mid(frame_ct*data_symbols_f*BPS+symbol_ct*BPS,BPS)));
	}

	//update coordinate
	vec coordinate_D_x(total_symbols);
	coordinate_D_x(0) = coordinate_D(0);
	for(int symbol_ct=1; symbol_ct<total_symbols; symbol_ct++)
		coordinate_D_x(symbol_ct) = coordinate_D_x(symbol_ct-1) - v_speed/f_s;

	//generate source-destination
	cvec h_SD(total_symbols), h_SD_LoS(total_symbols);
	TDL_Channel Rayleigh_SD;
	Rayleigh_SD.set_norm_doppler(fd_SD);
	cmat channel_SD;
	Rayleigh_SD.generate(total_symbols, channel_SD);
	cvec rayleigh_channels_SD = channel_SD.get_col(0);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SD = sqrt(sqr(coordinate_D_x(symbol_ct)-coordinate_S(0))+sqr(coordinate_D(1)-coordinate_S(1))+sqr(coordinate_D(2)-coordinate_S(2)));
		double Gamma_SD = pow(d_SD,-1.0*gamma_SD)*inv_dB(Gain_BF_dB)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_D(1)-coordinate_S(1))/(coordinate_D_x(symbol_ct)-coordinate_S(0)));
		h_SD_LoS(symbol_ct) = sqrt(Gamma_SD*K_SD/(K_SD+1))*exp(j*2*pi*symbol_ct*fd_SD*cos(AoA_mov));
		h_SD(symbol_ct) = h_SD_LoS(symbol_ct) + sqrt(Gamma_SD/(K_SD+1))*rayleigh_channels_SD(symbol_ct);
	}

	//generate source-RIS
	cmat h_SR(M_RIS,total_symbols), h_SR_LoS(M_RIS,total_symbols);
	TDL_Channel Rayleigh_SR;
	cmat rayleigh_channels_SR(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_SR.set_norm_doppler(fd_SR);
		cmat channel_SR;
		Rayleigh_SR.generate(total_symbols, channel_SR);
		rayleigh_channels_SR.set_row(channel_ct,channel_SR.get_col(0));
	}
	int M_RIS_y = (int) sqrt(M_RIS), M_RIS_z = M_RIS/M_RIS_y;
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SR = sqrt(sqr(coordinate_R(0)-coordinate_S(0))+sqr(coordinate_R(1)-coordinate_S(1))+sqr(coordinate_R(2)-coordinate_S(2)));
		double Gamma_SR = pow(d_SR,-1.0*gamma_SR)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		//update AoA
		double theta = acos((coordinate_S(2)-coordinate_R(2))/d_SR);
		double phi = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_SR_LoS(m_ct,symbol_ct) = sqrt(Gamma_SR*K_SR/(K_SR+1))*exp(j*2*pi*symbol_ct*fd_SR*cos(AoA_mov))*exp(j*pi*(m_y*sin(theta)*cos(phi)+m_z*sin(phi)));
				h_SR(m_ct,symbol_ct) = h_SR_LoS(m_ct,symbol_ct) + sqrt(Gamma_SR/(K_SR+1))*rayleigh_channels_SR(m_ct,symbol_ct);
			}
		}
	}

	//generate RIS-destination
	cmat h_RD(M_RIS,total_symbols), h_RD_LoS(M_RIS,total_symbols), h_SRD(M_RIS,total_symbols);
	TDL_Channel Rayleigh_RD;
	cmat rayleigh_channels_RD(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_RD.set_norm_doppler(fd_RD);
		cmat channel_RD;
		Rayleigh_RD.generate(total_symbols, channel_RD);
		rayleigh_channels_RD.set_row(channel_ct,channel_RD.get_col(0));
	}
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_RD = sqrt(sqr(coordinate_R(0)-coordinate_D_x(symbol_ct))+sqr(coordinate_R(1)-coordinate_D(1))+sqr(coordinate_R(2)-coordinate_D(2)));
		double Gamma_RD = pow(d_RD,-1.0*gamma_RD)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_D(1))/(coordinate_R(0)-coordinate_D_x(symbol_ct)));
		//update AoD
		double theta = acos((coordinate_D(2)-coordinate_R(2))/d_RD);
		double phi = atan((coordinate_D(1)-coordinate_R(1))/(coordinate_D_x(symbol_ct)-coordinate_R(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_RD_LoS(m_ct,symbol_ct) = sqrt(Gamma_RD*K_RD/(K_RD+1))*exp(j*2*pi*symbol_ct*fd_RD*cos(AoA_mov))*exp(-j*pi*(m_y*sin(theta)*cos(phi)-m_z*sin(phi)));
				h_RD(m_ct,symbol_ct) = h_RD_LoS(m_ct,symbol_ct) + sqrt(Gamma_RD/(K_RD+1))*rayleigh_channels_RD(m_ct,symbol_ct);
				h_SRD(m_ct,symbol_ct) = h_SR(m_ct,symbol_ct)*h_RD(m_ct,symbol_ct);
			}
		}
	}

	MSE_SD = 0.0;
	MSE_SRD = 0.0;
	MSE_AV = 0.0;
	cvec h_equi=zeros_c(total_symbols), y_all(total_symbols), v_all = N0*randn_c(total_symbols);
	for(int frame_ct=0; frame_ct<CSI_frames; frame_ct++) {
		y_all(frame_ct*N_f) = h_SD(frame_ct*N_f) + v_all(frame_ct*N_f);
		complex<double> h_SD_hat = y_all(frame_ct*N_f);
		cvec h_SRD_hat(M_RIS), alpha_RIS(M_RIS);
		complex<double > h_equi_hat=complex<double>(0.0,0.0);
		for(int m_ct=0; m_ct<M_RIS; m_ct++) {
			y_all(frame_ct*N_f+1+m_ct) = h_SD(frame_ct*N_f+1+m_ct) + h_SRD(m_ct,frame_ct*N_f+1+m_ct) + v_all(frame_ct*N_f+1+m_ct);
			y_all(frame_ct*N_f+1+m_ct) = y_all(frame_ct*N_f+1+m_ct) - h_SD_hat;
			h_SRD_hat(m_ct) = y_all(frame_ct*N_f+1+m_ct);
			alpha_RIS(m_ct) = h_SD_hat*conj(h_SRD_hat(m_ct))/(abs(h_SD_hat)*abs(h_SRD_hat(m_ct)));
			h_equi_hat = h_equi_hat + alpha_RIS(m_ct)*h_SRD_hat(m_ct);
		}
		h_equi_hat = h_equi_hat + h_SD_hat;
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++) {
			for(int m_ct=0; m_ct<M_RIS; m_ct++) {
				h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) = h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) + alpha_RIS(m_ct)*h_SRD(m_ct,frame_ct*N_f+M_RIS+1+symbol_ct);
				MSE_SRD = MSE_SRD + sqr(abs(h_SRD_hat(m_ct)-h_SRD(m_ct,frame_ct*N_f+M_RIS+1+symbol_ct)));
			}
			h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) = h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) + h_SD(frame_ct*N_f+M_RIS+1+symbol_ct);
			MSE_SD = MSE_SD + sqr(abs(h_SD(frame_ct*N_f+M_RIS+1+symbol_ct)-h_SD_hat));
			MSE_AV = MSE_AV + sqr(abs(h_equi(frame_ct*N_f+M_RIS+1+symbol_ct)-h_equi_hat));
		}
	}
	MSE_SD = MSE_SD/data_symbols;
	MSE_SRD = MSE_SRD/data_symbols;
	MSE_SRD = MSE_SRD/M_RIS;
	MSE_AV = MSE_AV/data_symbols;
}

bvec RIS_Ricean::RIS_Ricean_DFT_CSI(const bvec b, const double N0, const int N_f)
{
	int data_bits = b.length(), data_symbols = data_bits/BPS;
	bvec b_hat(data_bits);

	int data_symbols_f = N_f-(M_RIS+1), CSI_frames = data_symbols/data_symbols_f, total_symbols = N_f*CSI_frames;
//cout<<data_symbols<<" "<<data_symbols_f<<endl;
	//source encoding
	cvec s_tx = ones_c(total_symbols);
	for(int frame_ct=0; frame_ct<CSI_frames; frame_ct++) {
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++)
			s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) = Symbol_Set(bin2dec(b.mid(frame_ct*data_symbols_f*BPS+symbol_ct*BPS,BPS)));
	}

	//update coordinate
	vec coordinate_D_x(total_symbols);
	coordinate_D_x(0) = coordinate_D(0);
	for(int symbol_ct=1; symbol_ct<total_symbols; symbol_ct++)
		coordinate_D_x(symbol_ct) = coordinate_D_x(symbol_ct-1) - v_speed/f_s;

	//generate source-destination
	cvec h_SD(total_symbols), h_SD_LoS(total_symbols);
	TDL_Channel Rayleigh_SD;
	Rayleigh_SD.set_norm_doppler(fd_SD);
	cmat channel_SD;
	Rayleigh_SD.generate(total_symbols, channel_SD);
	cvec rayleigh_channels_SD = channel_SD.get_col(0);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SD = sqrt(sqr(coordinate_D_x(symbol_ct)-coordinate_S(0))+sqr(coordinate_D(1)-coordinate_S(1))+sqr(coordinate_D(2)-coordinate_S(2)));
		double Gamma_SD = pow(d_SD,-1.0*gamma_SD)*inv_dB(Gain_BF_dB)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_D(1)-coordinate_S(1))/(coordinate_D_x(symbol_ct)-coordinate_S(0)));
		h_SD_LoS(symbol_ct) = sqrt(Gamma_SD*K_SD/(K_SD+1))*exp(j*2*pi*symbol_ct*fd_SD*cos(AoA_mov));
		h_SD(symbol_ct) = h_SD_LoS(symbol_ct) + sqrt(Gamma_SD/(K_SD+1))*rayleigh_channels_SD(symbol_ct);
	}

	//generate source-RIS
	cmat h_SR(M_RIS,total_symbols), h_SR_LoS(M_RIS,total_symbols);
	TDL_Channel Rayleigh_SR;
	cmat rayleigh_channels_SR(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_SR.set_norm_doppler(fd_SR);
		cmat channel_SR;
		Rayleigh_SR.generate(total_symbols, channel_SR);
		rayleigh_channels_SR.set_row(channel_ct,channel_SR.get_col(0));
	}
	int M_RIS_y = (int) sqrt(M_RIS), M_RIS_z = M_RIS/M_RIS_y;
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SR = sqrt(sqr(coordinate_R(0)-coordinate_S(0))+sqr(coordinate_R(1)-coordinate_S(1))+sqr(coordinate_R(2)-coordinate_S(2)));
		double Gamma_SR = pow(d_SR,-1.0*gamma_SR)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		//update AoA
		double theta = acos((coordinate_S(2)-coordinate_R(2))/d_SR);
		double phi = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_SR_LoS(m_ct,symbol_ct) = sqrt(Gamma_SR*K_SR/(K_SR+1))*exp(j*2*pi*symbol_ct*fd_SR*cos(AoA_mov))*exp(j*pi*(m_y*sin(theta)*cos(phi)+m_z*sin(phi)));
				h_SR(m_ct,symbol_ct) = h_SR_LoS(m_ct,symbol_ct) + sqrt(Gamma_SR/(K_SR+1))*rayleigh_channels_SR(m_ct,symbol_ct);
			}
		}
	}

	//generate RIS-destination
	cmat h_RD(M_RIS,total_symbols), h_RD_LoS(M_RIS,total_symbols), h_SRD(M_RIS,total_symbols);
	TDL_Channel Rayleigh_RD;
	cmat rayleigh_channels_RD(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_RD.set_norm_doppler(fd_RD);
		cmat channel_RD;
		Rayleigh_RD.generate(total_symbols, channel_RD);
		rayleigh_channels_RD.set_row(channel_ct,channel_RD.get_col(0));
	}
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_RD = sqrt(sqr(coordinate_R(0)-coordinate_D_x(symbol_ct))+sqr(coordinate_R(1)-coordinate_D(1))+sqr(coordinate_R(2)-coordinate_D(2)));
		double Gamma_RD = pow(d_RD,-1.0*gamma_RD)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_D(1))/(coordinate_R(0)-coordinate_D_x(symbol_ct)));
		//update AoD
		double theta = acos((coordinate_D(2)-coordinate_R(2))/d_RD);
		double phi = atan((coordinate_D(1)-coordinate_R(1))/(coordinate_D_x(symbol_ct)-coordinate_R(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_RD_LoS(m_ct,symbol_ct) = sqrt(Gamma_RD*K_RD/(K_RD+1))*exp(j*2*pi*symbol_ct*fd_RD*cos(AoA_mov))*exp(-j*pi*(m_y*sin(theta)*cos(phi)-m_z*sin(phi)));
				h_RD(m_ct,symbol_ct) = h_RD_LoS(m_ct,symbol_ct) + sqrt(Gamma_RD/(K_RD+1))*rayleigh_channels_RD(m_ct,symbol_ct);
				h_SRD(m_ct,symbol_ct) = h_SR(m_ct,symbol_ct)*h_RD(m_ct,symbol_ct);
			}
		}
	}

	cvec h_equi=zeros_c(total_symbols), y_all(total_symbols), v_all = N0*randn_c(total_symbols);
	for(int frame_ct=0; frame_ct<CSI_frames; frame_ct++) {

		cmat y_p=zeros_c(1,M_RIS+1);
		for(int m_ct=0; m_ct<=M_RIS; m_ct++) {
			y_p(m_ct) = h_SD(frame_ct*N_f+m_ct)*DFT_Matrix(0,m_ct);
			for(int m_ct2=0; m_ct2<M_RIS; m_ct2++)
				y_p(m_ct) = y_p(m_ct) + h_SRD(m_ct2,frame_ct*N_f+m_ct)*DFT_Matrix(m_ct2+1,m_ct);
			y_p(m_ct) = y_p(m_ct) + v_all(frame_ct*N_f+m_ct);
		}

		cmat h_p = y_p*DFT_Matrix_inv;
		complex<double> h_SD_hat = h_p(0);
		cvec h_SRD_hat(M_RIS), alpha_RIS(M_RIS);
		complex<double > h_equi_hat=complex<double>(0.0,0.0);
		for(int m_ct=0; m_ct<M_RIS; m_ct++) {
			h_SRD_hat(m_ct) = h_p(1+m_ct);
			alpha_RIS(m_ct) = h_SD_hat*conj(h_SRD_hat(m_ct))/(abs(h_SD_hat)*abs(h_SRD_hat(m_ct)));
			h_equi_hat = h_equi_hat + alpha_RIS(m_ct)*h_SRD_hat(m_ct);
		}
		h_equi_hat = h_equi_hat + h_SD_hat;
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++) {
			for(int m_ct=0; m_ct<M_RIS; m_ct++)
				h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) = h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) + alpha_RIS(m_ct)*h_SRD(m_ct,frame_ct*N_f+M_RIS+1+symbol_ct);
			h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) = h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) + h_SD(frame_ct*N_f+M_RIS+1+symbol_ct);
			y_all(frame_ct*N_f+M_RIS+1+symbol_ct) = h_equi(frame_ct*N_f+M_RIS+1+symbol_ct)*s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) + v_all(frame_ct*N_f+M_RIS+1+symbol_ct);
			complex<double> z = y_all(frame_ct*N_f+M_RIS+1+symbol_ct)*conj(h_equi_hat)/sqr(abs(h_equi_hat));
			int index_hat = PSK_QAM_Dem(z);
			for(int bit_ct=0; bit_ct<BPS; bit_ct++)
				b_hat(frame_ct*data_symbols_f*BPS+symbol_ct*BPS+bit_ct)=Symbol_Mapping_Bin(index_hat,bit_ct);
		}
	}

	return b_hat;
}

void RIS_Ricean::MSE_RIS_Ricean_DFT_CSI(const bvec b, const double N0, const int N_f, double &MSE_SD, double &MSE_SRD, double &MSE_AV)
{
	int data_bits = b.length(), data_symbols = data_bits/BPS;

	int data_symbols_f = N_f-(M_RIS+1), CSI_frames = data_symbols/data_symbols_f, total_symbols = N_f*CSI_frames;
//cout<<data_symbols<<" "<<data_symbols_f<<endl;
	//source encoding
	cvec s_tx = ones_c(total_symbols);
	for(int frame_ct=0; frame_ct<CSI_frames; frame_ct++) {
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++)
			s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) = Symbol_Set(bin2dec(b.mid(frame_ct*data_symbols_f*BPS+symbol_ct*BPS,BPS)));
	}

	//update coordinate
	vec coordinate_D_x(total_symbols);
	coordinate_D_x(0) = coordinate_D(0);
	for(int symbol_ct=1; symbol_ct<total_symbols; symbol_ct++)
		coordinate_D_x(symbol_ct) = coordinate_D_x(symbol_ct-1) - v_speed/f_s;

	//generate source-destination
	cvec h_SD(total_symbols), h_SD_LoS(total_symbols);
	TDL_Channel Rayleigh_SD;
	Rayleigh_SD.set_norm_doppler(fd_SD);
	cmat channel_SD;
	Rayleigh_SD.generate(total_symbols, channel_SD);
	cvec rayleigh_channels_SD = channel_SD.get_col(0);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SD = sqrt(sqr(coordinate_D_x(symbol_ct)-coordinate_S(0))+sqr(coordinate_D(1)-coordinate_S(1))+sqr(coordinate_D(2)-coordinate_S(2)));
		double Gamma_SD = pow(d_SD,-1.0*gamma_SD)*inv_dB(Gain_BF_dB)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_D(1)-coordinate_S(1))/(coordinate_D_x(symbol_ct)-coordinate_S(0)));
		h_SD_LoS(symbol_ct) = sqrt(Gamma_SD*K_SD/(K_SD+1))*exp(j*2*pi*symbol_ct*fd_SD*cos(AoA_mov));
		h_SD(symbol_ct) = h_SD_LoS(symbol_ct) + sqrt(Gamma_SD/(K_SD+1))*rayleigh_channels_SD(symbol_ct);
	}

	//generate source-RIS
	cmat h_SR(M_RIS,total_symbols), h_SR_LoS(M_RIS,total_symbols);
	TDL_Channel Rayleigh_SR;
	cmat rayleigh_channels_SR(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_SR.set_norm_doppler(fd_SR);
		cmat channel_SR;
		Rayleigh_SR.generate(total_symbols, channel_SR);
		rayleigh_channels_SR.set_row(channel_ct,channel_SR.get_col(0));
	}
	int M_RIS_y = (int) sqrt(M_RIS), M_RIS_z = M_RIS/M_RIS_y;
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SR = sqrt(sqr(coordinate_R(0)-coordinate_S(0))+sqr(coordinate_R(1)-coordinate_S(1))+sqr(coordinate_R(2)-coordinate_S(2)));
		double Gamma_SR = pow(d_SR,-1.0*gamma_SR)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		//update AoA
		double theta = acos((coordinate_S(2)-coordinate_R(2))/d_SR);
		double phi = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_SR_LoS(m_ct,symbol_ct) = sqrt(Gamma_SR*K_SR/(K_SR+1))*exp(j*2*pi*symbol_ct*fd_SR*cos(AoA_mov))*exp(j*pi*(m_y*sin(theta)*cos(phi)+m_z*sin(phi)));
				h_SR(m_ct,symbol_ct) = h_SR_LoS(m_ct,symbol_ct) + sqrt(Gamma_SR/(K_SR+1))*rayleigh_channels_SR(m_ct,symbol_ct);
			}
		}
	}

	//generate RIS-destination
	cmat h_RD(M_RIS,total_symbols), h_RD_LoS(M_RIS,total_symbols), h_SRD(M_RIS,total_symbols);
	TDL_Channel Rayleigh_RD;
	cmat rayleigh_channels_RD(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_RD.set_norm_doppler(fd_RD);
		cmat channel_RD;
		Rayleigh_RD.generate(total_symbols, channel_RD);
		rayleigh_channels_RD.set_row(channel_ct,channel_RD.get_col(0));
	}
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_RD = sqrt(sqr(coordinate_R(0)-coordinate_D_x(symbol_ct))+sqr(coordinate_R(1)-coordinate_D(1))+sqr(coordinate_R(2)-coordinate_D(2)));
		double Gamma_RD = pow(d_RD,-1.0*gamma_RD)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_D(1))/(coordinate_R(0)-coordinate_D_x(symbol_ct)));
		//update AoD
		double theta = acos((coordinate_D(2)-coordinate_R(2))/d_RD);
		double phi = atan((coordinate_D(1)-coordinate_R(1))/(coordinate_D_x(symbol_ct)-coordinate_R(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_RD_LoS(m_ct,symbol_ct) = sqrt(Gamma_RD*K_RD/(K_RD+1))*exp(j*2*pi*symbol_ct*fd_RD*cos(AoA_mov))*exp(-j*pi*(m_y*sin(theta)*cos(phi)-m_z*sin(phi)));
				h_RD(m_ct,symbol_ct) = h_RD_LoS(m_ct,symbol_ct) + sqrt(Gamma_RD/(K_RD+1))*rayleigh_channels_RD(m_ct,symbol_ct);
				h_SRD(m_ct,symbol_ct) = h_SR(m_ct,symbol_ct)*h_RD(m_ct,symbol_ct);
			}
		}
	}

	MSE_SD = 0.0;
	MSE_SRD = 0.0;
	MSE_AV = 0.0;
	cvec h_equi=zeros_c(total_symbols), y_all(total_symbols), v_all = N0*randn_c(total_symbols);
	for(int frame_ct=0; frame_ct<CSI_frames; frame_ct++) {

		cmat y_p=zeros_c(1,M_RIS+1);
		for(int m_ct=0; m_ct<=M_RIS; m_ct++) {
			y_p(m_ct) = h_SD(frame_ct*N_f+m_ct)*DFT_Matrix(0,m_ct);
			for(int m_ct2=0; m_ct2<M_RIS; m_ct2++)
				y_p(m_ct) = y_p(m_ct) + h_SRD(m_ct2,frame_ct*N_f+m_ct)*DFT_Matrix(m_ct2+1,m_ct);
			y_p(m_ct) = y_p(m_ct) + v_all(frame_ct*N_f+m_ct);
		}

		cmat h_p = y_p*DFT_Matrix_inv;
		complex<double> h_SD_hat = h_p(0);
		cvec h_SRD_hat(M_RIS), alpha_RIS(M_RIS);
		complex<double > h_equi_hat=complex<double>(0.0,0.0);
		for(int m_ct=0; m_ct<M_RIS; m_ct++) {
			h_SRD_hat(m_ct) = h_p(1+m_ct);
			alpha_RIS(m_ct) = h_SD_hat*conj(h_SRD_hat(m_ct))/(abs(h_SD_hat)*abs(h_SRD_hat(m_ct)));
			h_equi_hat = h_equi_hat + alpha_RIS(m_ct)*h_SRD_hat(m_ct);
		}
		h_equi_hat = h_equi_hat + h_SD_hat;
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++) {
			for(int m_ct=0; m_ct<M_RIS; m_ct++) {
				h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) = h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) + alpha_RIS(m_ct)*h_SRD(m_ct,frame_ct*N_f+M_RIS+1+symbol_ct);
				MSE_SRD = MSE_SRD + sqr(abs(h_SRD_hat(m_ct)-h_SRD(m_ct,frame_ct*N_f+M_RIS+1+symbol_ct)));
			}
			h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) = h_equi(frame_ct*N_f+M_RIS+1+symbol_ct) + h_SD(frame_ct*N_f+M_RIS+1+symbol_ct);
			MSE_SD = MSE_SD + sqr(abs(h_SD(frame_ct*N_f+M_RIS+1+symbol_ct)-h_SD_hat));
			MSE_AV = MSE_AV + sqr(abs(h_equi(frame_ct*N_f+M_RIS+1+symbol_ct)-h_equi_hat));
		}
	}
	MSE_SD = MSE_SD/data_symbols;
	MSE_SRD = MSE_SRD/data_symbols;
	MSE_SRD = MSE_SRD/M_RIS;
	MSE_AV = MSE_AV/data_symbols;


}

bvec RIS_Ricean::RIS_Ricean_MMSE_CSI(const bvec b, const double N0, const int N_f, const int N_w)
{
	int data_bits = b.length(), data_symbols = data_bits/BPS;
	bvec b_hat(data_bits);

	int data_symbols_f = N_f-(M_RIS+1), CSI_frames = data_symbols/data_symbols_f+N_w-1, total_symbols = N_f*CSI_frames;

	//source encoding
	cvec s_tx = ones_c(total_symbols);
	for(int frame_ct=(N_w-1); frame_ct<CSI_frames; frame_ct++) {
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++)
			s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) = Symbol_Set(bin2dec(b.mid((frame_ct-(N_w-1))*data_symbols_f*BPS+symbol_ct*BPS,BPS)));
	}

	//update coordinate
	vec coordinate_D_x(total_symbols);
	coordinate_D_x(0) = coordinate_D(0);
	for(int symbol_ct=1; symbol_ct<total_symbols; symbol_ct++)
		coordinate_D_x(symbol_ct) = coordinate_D_x(symbol_ct-1) - v_speed/f_s;

	//generate source-destination
	cvec h_SD(total_symbols), h_SD_LoS(total_symbols);
	TDL_Channel Rayleigh_SD;
	Rayleigh_SD.set_norm_doppler(fd_SD);
	cmat channel_SD;
	Rayleigh_SD.generate(total_symbols, channel_SD);
	cvec rayleigh_channels_SD = channel_SD.get_col(0);
	vec Gamma_SD(total_symbols);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SD = sqrt(sqr(coordinate_D_x(symbol_ct)-coordinate_S(0))+sqr(coordinate_D(1)-coordinate_S(1))+sqr(coordinate_D(2)-coordinate_S(2)));
		Gamma_SD(symbol_ct) = pow(d_SD,-1.0*gamma_SD)*inv_dB(Gain_BF_dB)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_D(1)-coordinate_S(1))/(coordinate_D_x(symbol_ct)-coordinate_S(0)));
		h_SD_LoS(symbol_ct) = sqrt(Gamma_SD(symbol_ct)*K_SD/(K_SD+1))*exp(j*2*pi*symbol_ct*fd_SD*cos(AoA_mov));
		h_SD(symbol_ct) = h_SD_LoS(symbol_ct) + sqrt(Gamma_SD(symbol_ct)/(K_SD+1))*rayleigh_channels_SD(symbol_ct);
	}

	//generate source-RIS
	cmat h_SR(M_RIS,total_symbols), h_SR_LoS(M_RIS,total_symbols);
	TDL_Channel Rayleigh_SR;
	cmat rayleigh_channels_SR(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_SR.set_norm_doppler(fd_SR);
		cmat channel_SR;
		Rayleigh_SR.generate(total_symbols, channel_SR);
		rayleigh_channels_SR.set_row(channel_ct,channel_SR.get_col(0));
	}
	int M_RIS_y = (int) sqrt(M_RIS), M_RIS_z = M_RIS/M_RIS_y;
	vec Gamma_SR(total_symbols);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SR = sqrt(sqr(coordinate_R(0)-coordinate_S(0))+sqr(coordinate_R(1)-coordinate_S(1))+sqr(coordinate_R(2)-coordinate_S(2)));
		Gamma_SR(symbol_ct) = pow(d_SR,-1.0*gamma_SR)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		//update AoA
		double theta = acos((coordinate_S(2)-coordinate_R(2))/d_SR);
		double phi = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_SR_LoS(m_ct,symbol_ct) = sqrt(Gamma_SR(symbol_ct)*K_SR/(K_SR+1))*exp(j*2*pi*symbol_ct*fd_SR*cos(AoA_mov))*exp(j*pi*(m_y*sin(theta)*cos(phi)+m_z*sin(phi)));
				h_SR(m_ct,symbol_ct) = h_SR_LoS(m_ct,symbol_ct) + sqrt(Gamma_SR(symbol_ct)/(K_SR+1))*rayleigh_channels_SR(m_ct,symbol_ct);
			}
		}
	}

	//generate RIS-destination
	cmat h_RD(M_RIS,total_symbols), h_RD_LoS(M_RIS,total_symbols), h_SRD(M_RIS,total_symbols);
	TDL_Channel Rayleigh_RD;
	cmat rayleigh_channels_RD(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_RD.set_norm_doppler(fd_RD);
		cmat channel_RD;
		Rayleigh_RD.generate(total_symbols, channel_RD);
		rayleigh_channels_RD.set_row(channel_ct,channel_RD.get_col(0));
	}
	vec Gamma_RD(total_symbols);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_RD = sqrt(sqr(coordinate_R(0)-coordinate_D_x(symbol_ct))+sqr(coordinate_R(1)-coordinate_D(1))+sqr(coordinate_R(2)-coordinate_D(2)));
		Gamma_RD(symbol_ct) = pow(d_RD,-1.0*gamma_RD)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_D(1))/(coordinate_R(0)-coordinate_D_x(symbol_ct)));
		//update AoD
		double theta = acos((coordinate_D(2)-coordinate_R(2))/d_RD);
		double phi = atan((coordinate_D(1)-coordinate_R(1))/(coordinate_D_x(symbol_ct)-coordinate_R(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_RD_LoS(m_ct,symbol_ct) = sqrt(Gamma_RD(symbol_ct)*K_RD/(K_RD+1))*exp(j*2*pi*symbol_ct*fd_RD*cos(AoA_mov))*exp(-j*pi*(m_y*sin(theta)*cos(phi)-m_z*sin(phi)));
				h_RD(m_ct,symbol_ct) = h_RD_LoS(m_ct,symbol_ct) + sqrt(Gamma_RD(symbol_ct)/(K_RD+1))*rayleigh_channels_RD(m_ct,symbol_ct);
				h_SRD(m_ct,symbol_ct) = h_SR(m_ct,symbol_ct)*h_RD(m_ct,symbol_ct);
			}
		}
	}

	cvec h_equi=zeros_c(total_symbols), h_equi_hat=zeros_c(total_symbols), y_all(total_symbols), v_all = N0*randn_c(total_symbols), h_SD_hat=zeros_c(total_symbols), N0_SD=zeros_c(total_symbols);
	cmat h_SRD_hat = zeros_c(M_RIS,total_symbols), alpha_RIS=zeros_c(M_RIS,total_symbols);
	for(int frame_ct=0; frame_ct<(N_w-1); frame_ct++) {
		y_all(frame_ct*N_f) = h_SD(frame_ct*N_f) + v_all(frame_ct*N_f);
		for(int m_ct=0; m_ct<M_RIS; m_ct++)
			y_all(frame_ct*N_f+1+m_ct) = h_SRD(m_ct,frame_ct*N_f+1+m_ct) + v_all(frame_ct*N_f+1+m_ct);
	}
	for(int frame_ct=(N_w-1); frame_ct<CSI_frames; frame_ct++) {
		y_all(frame_ct*N_f) = h_SD(frame_ct*N_f) + v_all(frame_ct*N_f);
		for(int m_ct=0; m_ct<M_RIS; m_ct++)
			y_all(frame_ct*N_f+1+m_ct) = h_SD(frame_ct*N_f+1+m_ct) + h_SRD(m_ct,frame_ct*N_f+1+m_ct) + v_all(frame_ct*N_f+1+m_ct);
		cmat C_SD(N_w,N_w);
		for(int i_ct=0; i_ct<N_w; i_ct++) {
			for(int j_ct=0; j_ct<N_w; j_ct++) {
				int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f;
				int n_index = (frame_ct-(N_w-1)+j_ct)*N_f;
				C_SD(i_ct,j_ct) = h_SD_LoS(n_index_hat)*conj(h_SD_LoS(n_index)) + (sqrt(Gamma_SD(n_index_hat)*Gamma_SD(n_index))/(1+K_SD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SD);
			}
			C_SD = C_SD + N0*eye_c(N_w);
		}
		cmat C_SD_inv = inv(C_SD);
		for(int m_ct=0; m_ct<M_RIS; m_ct++) {
			cmat e_SD(N_w,1);
			for(int i_ct=0; i_ct<N_w; i_ct++) {
				int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f;
				int n_index = frame_ct*N_f+1+m_ct;
				e_SD(i_ct) = h_SD_LoS(n_index_hat)*conj(h_SD_LoS(n_index)) + (sqrt(Gamma_SD(n_index_hat)*Gamma_SD(n_index))/(1+K_SD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SD);
			}
			cmat w_SD = conj(C_SD_inv*e_SD);
			for(int i_ct=0; i_ct<N_w; i_ct++)
				h_SD_hat(frame_ct*N_f+1+m_ct) = h_SD_hat(frame_ct*N_f+1+m_ct) + w_SD(i_ct)*y_all((frame_ct-(N_w-1)+i_ct)*N_f);
			y_all(frame_ct*N_f+1+m_ct) = y_all(frame_ct*N_f+1+m_ct) - h_SD_hat(frame_ct*N_f+1+m_ct);
			cmat temp = hermitian_transpose(e_SD)*C_SD_inv*e_SD, temp2 = hermitian_transpose(e_SD)*hermitian_transpose(C_SD_inv)*e_SD;
//if(abs(temp(0)-temp2(0))>1e-6)
//	cout<<temp(0)<<" "<<temp(0)<<" "<<temp(0)-temp2(0)<<endl;
			N0_SD(frame_ct*N_f+1+m_ct) = Gamma_SD(frame_ct*N_f+1+m_ct) - real(temp(0));
		}


		Array<cmat> C_SRD_inv(M_RIS);
		for(int m_ct=0; m_ct<M_RIS; m_ct++) {
			cmat C_SRD(N_w,N_w), N0_SD_temp = zeros_c(N_w,N_w);
			for(int i_ct=0; i_ct<N_w; i_ct++) {
				for(int j_ct=0; j_ct<N_w; j_ct++) {
					int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1;
					int n_index = (frame_ct-(N_w-1)+j_ct)*N_f+m_ct+1;
					C_SRD(i_ct,j_ct) = h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index));
					C_SRD(i_ct,j_ct) = C_SRD(i_ct,j_ct) + h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD);
					C_SRD(i_ct,j_ct) = C_SRD(i_ct,j_ct) + h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index))*(sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
					C_SRD(i_ct,j_ct) = C_SRD(i_ct,j_ct) + (sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD)*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
				}
				N0_SD_temp(i_ct,i_ct) = N0_SD((frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1);
			}
			C_SRD = C_SRD + N0_SD_temp + N0*eye_c(N_w);
			C_SRD_inv(m_ct) = inv(C_SRD);
		}
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++) {
			cmat e_SD(N_w,1);
			for(int i_ct=0; i_ct<N_w; i_ct++) {
				int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f;
				int n_index = frame_ct*N_f+symbol_ct+M_RIS+1;
				e_SD(i_ct) = h_SD_LoS(n_index_hat)*conj(h_SD_LoS(n_index)) + (sqrt(Gamma_SD(n_index_hat)*Gamma_SD(n_index))/(1+K_SD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SD);
			}
			cmat w_SD = conj(C_SD_inv*e_SD);
			for(int i_ct=0; i_ct<N_w; i_ct++)
				h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1) = h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1) + w_SD(i_ct)*y_all((frame_ct-(N_w-1)+i_ct)*N_f);

			for(int m_ct=0; m_ct<M_RIS; m_ct++) {
				cmat e_SRD(N_w,1);
				for(int i_ct=0; i_ct<N_w; i_ct++) {
					int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1;
					int n_index = frame_ct*N_f+symbol_ct+M_RIS+1;
					e_SRD(i_ct) = h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index));
					e_SRD(i_ct) = e_SRD(i_ct) + h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD);
					e_SRD(i_ct) = e_SRD(i_ct) + h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index))*(sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
					e_SRD(i_ct) = e_SRD(i_ct) + (sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD)*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
				}
				cmat w_SRD_m = conj(C_SRD_inv(m_ct)*e_SRD);
				for(int i_ct=0; i_ct<N_w; i_ct++)
					h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1) = h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1) + w_SRD_m(i_ct)*y_all((frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1);

				alpha_RIS(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1) = h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1)*conj(h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1))/(abs(h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1))*abs(h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1)));
				h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) + alpha_RIS(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1)*h_SRD(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1);
				h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) + alpha_RIS(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1)*h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1);
			}
			h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) + h_SD(frame_ct*N_f+symbol_ct+M_RIS+1);
			h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) + h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1);
			y_all(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi(frame_ct*N_f+symbol_ct+M_RIS+1)*s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) + v_all(frame_ct*N_f+symbol_ct+M_RIS+1);
			complex<double> z = y_all(frame_ct*N_f+symbol_ct+M_RIS+1)*conj(h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1))/sqr(abs(h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1)));
			int index_hat = PSK_QAM_Dem(z);
			for(int bit_ct=0; bit_ct<BPS; bit_ct++)
				b_hat((frame_ct-(N_w-1))*data_symbols_f*BPS+symbol_ct*BPS+bit_ct)=Symbol_Mapping_Bin(index_hat,bit_ct);
		}

	}



	return b_hat;
}

bvec RIS_Ricean::RIS_Ricean_MMSE_CSI_RandomPhase(const bvec b, const double N0, const int N_f, const int N_w)
{
	int data_bits = b.length(), data_symbols = data_bits/BPS;
	bvec b_hat(data_bits);

	int data_symbols_f = N_f-(M_RIS+1), CSI_frames = data_symbols/data_symbols_f+N_w-1, total_symbols = N_f*CSI_frames;

	//source encoding
	cvec s_tx = ones_c(total_symbols);
	for(int frame_ct=(N_w-1); frame_ct<CSI_frames; frame_ct++) {
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++)
			s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) = Symbol_Set(bin2dec(b.mid((frame_ct-(N_w-1))*data_symbols_f*BPS+symbol_ct*BPS,BPS)));
	}

	//update coordinate
	vec coordinate_D_x(total_symbols);
	coordinate_D_x(0) = coordinate_D(0);
	for(int symbol_ct=1; symbol_ct<total_symbols; symbol_ct++)
		coordinate_D_x(symbol_ct) = coordinate_D_x(symbol_ct-1) - v_speed/f_s;

	//generate source-destination
	cvec h_SD(total_symbols), h_SD_LoS(total_symbols);
	TDL_Channel Rayleigh_SD;
	Rayleigh_SD.set_norm_doppler(fd_SD);
	cmat channel_SD;
	Rayleigh_SD.generate(total_symbols, channel_SD);
	cvec rayleigh_channels_SD = channel_SD.get_col(0);
	vec Gamma_SD(total_symbols);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SD = sqrt(sqr(coordinate_D_x(symbol_ct)-coordinate_S(0))+sqr(coordinate_D(1)-coordinate_S(1))+sqr(coordinate_D(2)-coordinate_S(2)));
		Gamma_SD(symbol_ct) = pow(d_SD,-1.0*gamma_SD)*inv_dB(Gain_BF_dB)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_D(1)-coordinate_S(1))/(coordinate_D_x(symbol_ct)-coordinate_S(0)));
		h_SD_LoS(symbol_ct) = sqrt(Gamma_SD(symbol_ct)*K_SD/(K_SD+1))*exp(j*2*pi*symbol_ct*fd_SD*cos(AoA_mov));
		h_SD(symbol_ct) = h_SD_LoS(symbol_ct) + sqrt(Gamma_SD(symbol_ct)/(K_SD+1))*rayleigh_channels_SD(symbol_ct);
	}

	//generate source-RIS
	cmat h_SR(M_RIS,total_symbols), h_SR_LoS(M_RIS,total_symbols);
	TDL_Channel Rayleigh_SR;
	cmat rayleigh_channels_SR(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_SR.set_norm_doppler(fd_SR);
		cmat channel_SR;
		Rayleigh_SR.generate(total_symbols, channel_SR);
		rayleigh_channels_SR.set_row(channel_ct,channel_SR.get_col(0));
	}
	int M_RIS_y = (int) sqrt(M_RIS), M_RIS_z = M_RIS/M_RIS_y;
	vec Gamma_SR(total_symbols);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SR = sqrt(sqr(coordinate_R(0)-coordinate_S(0))+sqr(coordinate_R(1)-coordinate_S(1))+sqr(coordinate_R(2)-coordinate_S(2)));
		Gamma_SR(symbol_ct) = pow(d_SR,-1.0*gamma_SR)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		//update AoA
		double theta = acos((coordinate_S(2)-coordinate_R(2))/d_SR);
		double phi = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_SR_LoS(m_ct,symbol_ct) = sqrt(Gamma_SR(symbol_ct)*K_SR/(K_SR+1))*exp(j*2*pi*symbol_ct*fd_SR*cos(AoA_mov))*exp(j*pi*(m_y*sin(theta)*cos(phi)+m_z*sin(phi)));
				h_SR(m_ct,symbol_ct) = h_SR_LoS(m_ct,symbol_ct) + sqrt(Gamma_SR(symbol_ct)/(K_SR+1))*rayleigh_channels_SR(m_ct,symbol_ct);
			}
		}
	}

	//generate RIS-destination
	cmat h_RD(M_RIS,total_symbols), h_RD_LoS(M_RIS,total_symbols), h_SRD(M_RIS,total_symbols);
	TDL_Channel Rayleigh_RD;
	cmat rayleigh_channels_RD(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_RD.set_norm_doppler(fd_RD);
		cmat channel_RD;
		Rayleigh_RD.generate(total_symbols, channel_RD);
		rayleigh_channels_RD.set_row(channel_ct,channel_RD.get_col(0));
	}
	vec Gamma_RD(total_symbols);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_RD = sqrt(sqr(coordinate_R(0)-coordinate_D_x(symbol_ct))+sqr(coordinate_R(1)-coordinate_D(1))+sqr(coordinate_R(2)-coordinate_D(2)));
		Gamma_RD(symbol_ct) = pow(d_RD,-1.0*gamma_RD)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_D(1))/(coordinate_R(0)-coordinate_D_x(symbol_ct)));
		//update AoD
		double theta = acos((coordinate_D(2)-coordinate_R(2))/d_RD);
		double phi = atan((coordinate_D(1)-coordinate_R(1))/(coordinate_D_x(symbol_ct)-coordinate_R(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_RD_LoS(m_ct,symbol_ct) = sqrt(Gamma_RD(symbol_ct)*K_RD/(K_RD+1))*exp(j*2*pi*symbol_ct*fd_RD*cos(AoA_mov))*exp(-j*pi*(m_y*sin(theta)*cos(phi)-m_z*sin(phi)));
				h_RD(m_ct,symbol_ct) = h_RD_LoS(m_ct,symbol_ct) + sqrt(Gamma_RD(symbol_ct)/(K_RD+1))*rayleigh_channels_RD(m_ct,symbol_ct);
				h_SRD(m_ct,symbol_ct) = h_SR(m_ct,symbol_ct)*h_RD(m_ct,symbol_ct);
			}
		}
	}

	cvec h_equi=zeros_c(total_symbols), h_equi_hat=zeros_c(total_symbols), y_all(total_symbols), v_all = N0*randn_c(total_symbols), h_SD_hat=zeros_c(total_symbols), N0_SD=zeros_c(total_symbols);
	cmat h_SRD_hat = zeros_c(M_RIS,total_symbols), alpha_RIS=randn_c(M_RIS,total_symbols);
	alpha_RIS = elem_div(alpha_RIS,to_cmat(abs(alpha_RIS)));
	for(int frame_ct=0; frame_ct<(N_w-1); frame_ct++) {
		y_all(frame_ct*N_f) = h_SD(frame_ct*N_f) + v_all(frame_ct*N_f);
		for(int m_ct=0; m_ct<M_RIS; m_ct++)
			y_all(frame_ct*N_f+1+m_ct) = h_SRD(m_ct,frame_ct*N_f+1+m_ct) + v_all(frame_ct*N_f+1+m_ct);
	}
	for(int frame_ct=(N_w-1); frame_ct<CSI_frames; frame_ct++) {
		y_all(frame_ct*N_f) = h_SD(frame_ct*N_f) + v_all(frame_ct*N_f);
		for(int m_ct=0; m_ct<M_RIS; m_ct++)
			y_all(frame_ct*N_f+1+m_ct) = h_SD(frame_ct*N_f+1+m_ct) + h_SRD(m_ct,frame_ct*N_f+1+m_ct) + v_all(frame_ct*N_f+1+m_ct);
		cmat C_SD(N_w,N_w);
		for(int i_ct=0; i_ct<N_w; i_ct++) {
			for(int j_ct=0; j_ct<N_w; j_ct++) {
				int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f;
				int n_index = (frame_ct-(N_w-1)+j_ct)*N_f;
				C_SD(i_ct,j_ct) = h_SD_LoS(n_index_hat)*conj(h_SD_LoS(n_index)) + (sqrt(Gamma_SD(n_index_hat)*Gamma_SD(n_index))/(1+K_SD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SD);
			}
			C_SD = C_SD + N0*eye_c(N_w);
		}
		cmat C_SD_inv = inv(C_SD);
		for(int m_ct=0; m_ct<M_RIS; m_ct++) {
			cmat e_SD(N_w,1);
			for(int i_ct=0; i_ct<N_w; i_ct++) {
				int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f;
				int n_index = frame_ct*N_f+1+m_ct;
				e_SD(i_ct) = h_SD_LoS(n_index_hat)*conj(h_SD_LoS(n_index)) + (sqrt(Gamma_SD(n_index_hat)*Gamma_SD(n_index))/(1+K_SD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SD);
			}
			cmat w_SD = conj(C_SD_inv*e_SD);
			for(int i_ct=0; i_ct<N_w; i_ct++)
				h_SD_hat(frame_ct*N_f+1+m_ct) = h_SD_hat(frame_ct*N_f+1+m_ct) + w_SD(i_ct)*y_all((frame_ct-(N_w-1)+i_ct)*N_f);
			y_all(frame_ct*N_f+1+m_ct) = y_all(frame_ct*N_f+1+m_ct) - h_SD_hat(frame_ct*N_f+1+m_ct);
			cmat temp = hermitian_transpose(e_SD)*C_SD_inv*e_SD, temp2 = hermitian_transpose(e_SD)*hermitian_transpose(C_SD_inv)*e_SD;
//if(abs(temp(0)-temp2(0))>1e-6)
//	cout<<temp(0)<<" "<<temp(0)<<" "<<temp(0)-temp2(0)<<endl;
			N0_SD(frame_ct*N_f+1+m_ct) = Gamma_SD(frame_ct*N_f+1+m_ct) - real(temp(0));
		}


		Array<cmat> C_SRD_inv(M_RIS);
		for(int m_ct=0; m_ct<M_RIS; m_ct++) {
			cmat C_SRD(N_w,N_w), N0_SD_temp = zeros_c(N_w,N_w);
			for(int i_ct=0; i_ct<N_w; i_ct++) {
				for(int j_ct=0; j_ct<N_w; j_ct++) {
					int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1;
					int n_index = (frame_ct-(N_w-1)+j_ct)*N_f+m_ct+1;
					C_SRD(i_ct,j_ct) = h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index));
					C_SRD(i_ct,j_ct) = C_SRD(i_ct,j_ct) + h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD);
					C_SRD(i_ct,j_ct) = C_SRD(i_ct,j_ct) + h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index))*(sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
					C_SRD(i_ct,j_ct) = C_SRD(i_ct,j_ct) + (sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD)*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
				}
				N0_SD_temp(i_ct,i_ct) = N0_SD((frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1);
			}
			C_SRD = C_SRD + N0_SD_temp + N0*eye_c(N_w);
			C_SRD_inv(m_ct) = inv(C_SRD);
		}
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++) {
			cmat e_SD(N_w,1);
			for(int i_ct=0; i_ct<N_w; i_ct++) {
				int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f;
				int n_index = frame_ct*N_f+symbol_ct+M_RIS+1;
				e_SD(i_ct) = h_SD_LoS(n_index_hat)*conj(h_SD_LoS(n_index)) + (sqrt(Gamma_SD(n_index_hat)*Gamma_SD(n_index))/(1+K_SD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SD);
			}
			cmat w_SD = conj(C_SD_inv*e_SD);
			for(int i_ct=0; i_ct<N_w; i_ct++)
				h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1) = h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1) + w_SD(i_ct)*y_all((frame_ct-(N_w-1)+i_ct)*N_f);

			for(int m_ct=0; m_ct<M_RIS; m_ct++) {
				cmat e_SRD(N_w,1);
				for(int i_ct=0; i_ct<N_w; i_ct++) {
					int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1;
					int n_index = frame_ct*N_f+symbol_ct+M_RIS+1;
					e_SRD(i_ct) = h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index));
					e_SRD(i_ct) = e_SRD(i_ct) + h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD);
					e_SRD(i_ct) = e_SRD(i_ct) + h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index))*(sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
					e_SRD(i_ct) = e_SRD(i_ct) + (sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD)*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
				}
				cmat w_SRD_m = conj(C_SRD_inv(m_ct)*e_SRD);
				for(int i_ct=0; i_ct<N_w; i_ct++)
					h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1) = h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1) + w_SRD_m(i_ct)*y_all((frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1);

//				alpha_RIS(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1) = h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1)*conj(h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1))/(abs(h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1))*abs(h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1)));
				h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) + alpha_RIS(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1)*h_SRD(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1);
				h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) + alpha_RIS(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1)*h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1);
			}
			h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) + h_SD(frame_ct*N_f+symbol_ct+M_RIS+1);
			h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) + h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1);
			y_all(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi(frame_ct*N_f+symbol_ct+M_RIS+1)*s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) + v_all(frame_ct*N_f+symbol_ct+M_RIS+1);
			complex<double> z = y_all(frame_ct*N_f+symbol_ct+M_RIS+1)*conj(h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1))/sqr(abs(h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1)));
			int index_hat = PSK_QAM_Dem(z);
			for(int bit_ct=0; bit_ct<BPS; bit_ct++)
				b_hat((frame_ct-(N_w-1))*data_symbols_f*BPS+symbol_ct*BPS+bit_ct)=Symbol_Mapping_Bin(index_hat,bit_ct);
		}

	}



	return b_hat;
}

bvec RIS_Ricean::RIS_Ricean_MMSE_CSI2(const bvec b, const double N0, const int N_f, const int N_w)
{
	int data_bits = b.length(), data_symbols = data_bits/BPS;
	bvec b_hat(data_bits);

	int data_symbols_f = N_f-(M_RIS+1), CSI_frames = data_symbols/data_symbols_f+N_w-1, total_symbols = N_f*CSI_frames;

	//source encoding
	cvec s_tx = ones_c(total_symbols);
	for(int frame_ct=(N_w-1); frame_ct<CSI_frames; frame_ct++) {
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++)
			s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) = Symbol_Set(bin2dec(b.mid((frame_ct-(N_w-1))*data_symbols_f*BPS+symbol_ct*BPS,BPS)));
	}

	//update coordinate
	vec coordinate_D_x(total_symbols);
	coordinate_D_x(0) = coordinate_D(0);
	for(int symbol_ct=1; symbol_ct<total_symbols; symbol_ct++)
		coordinate_D_x(symbol_ct) = coordinate_D_x(symbol_ct-1) - v_speed/f_s;

	//generate source-destination
	cvec h_SD(total_symbols), h_SD_LoS(total_symbols);
	TDL_Channel Rayleigh_SD;
	Rayleigh_SD.set_norm_doppler(fd_SD);
	cmat channel_SD;
	Rayleigh_SD.generate(total_symbols, channel_SD);
	cvec rayleigh_channels_SD = channel_SD.get_col(0);
	vec Gamma_SD(total_symbols);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SD = sqrt(sqr(coordinate_D_x(symbol_ct)-coordinate_S(0))+sqr(coordinate_D(1)-coordinate_S(1))+sqr(coordinate_D(2)-coordinate_S(2)));
		Gamma_SD(symbol_ct) = pow(d_SD,-1.0*gamma_SD)*inv_dB(Gain_BF_dB)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_D(1)-coordinate_S(1))/(coordinate_D_x(symbol_ct)-coordinate_S(0)));
		h_SD_LoS(symbol_ct) = sqrt(Gamma_SD(symbol_ct)*K_SD/(K_SD+1))*exp(j*2*pi*symbol_ct*fd_SD*cos(AoA_mov));
		h_SD(symbol_ct) = h_SD_LoS(symbol_ct) + sqrt(Gamma_SD(symbol_ct)/(K_SD+1))*rayleigh_channels_SD(symbol_ct);
	}

	//generate source-RIS
	cmat h_SR(M_RIS,total_symbols), h_SR_LoS(M_RIS,total_symbols);
	TDL_Channel Rayleigh_SR;
	cmat rayleigh_channels_SR(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_SR.set_norm_doppler(fd_SR);
		cmat channel_SR;
		Rayleigh_SR.generate(total_symbols, channel_SR);
		rayleigh_channels_SR.set_row(channel_ct,channel_SR.get_col(0));
	}
	int M_RIS_y = (int) sqrt(M_RIS), M_RIS_z = M_RIS/M_RIS_y;
	vec Gamma_SR(total_symbols);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_SR = sqrt(sqr(coordinate_R(0)-coordinate_S(0))+sqr(coordinate_R(1)-coordinate_S(1))+sqr(coordinate_R(2)-coordinate_S(2)));
		Gamma_SR(symbol_ct) = pow(d_SR,-1.0*gamma_SR)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		//update AoA
		double theta = acos((coordinate_S(2)-coordinate_R(2))/d_SR);
		double phi = atan((coordinate_R(1)-coordinate_S(1))/(coordinate_R(0)-coordinate_S(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_SR_LoS(m_ct,symbol_ct) = sqrt(Gamma_SR(symbol_ct)*K_SR/(K_SR+1))*exp(j*2*pi*symbol_ct*fd_SR*cos(AoA_mov))*exp(j*pi*(m_y*sin(theta)*cos(phi)+m_z*sin(phi)));
				h_SR(m_ct,symbol_ct) = h_SR_LoS(m_ct,symbol_ct) + sqrt(Gamma_SR(symbol_ct)/(K_SR+1))*rayleigh_channels_SR(m_ct,symbol_ct);
			}
		}
	}

	//generate RIS-destination
	cmat h_RD(M_RIS,total_symbols), h_RD_LoS(M_RIS,total_symbols), h_SRD(M_RIS,total_symbols);
	TDL_Channel Rayleigh_RD;
	cmat rayleigh_channels_RD(M_RIS,total_symbols);
	for(int channel_ct = 0; channel_ct < M_RIS; channel_ct++) {
		Rayleigh_RD.set_norm_doppler(fd_RD);
		cmat channel_RD;
		Rayleigh_RD.generate(total_symbols, channel_RD);
		rayleigh_channels_RD.set_row(channel_ct,channel_RD.get_col(0));
	}
	vec Gamma_RD(total_symbols);
	for(int symbol_ct=0; symbol_ct<total_symbols; symbol_ct++) {
		//update large scale
		double d_RD = sqrt(sqr(coordinate_R(0)-coordinate_D_x(symbol_ct))+sqr(coordinate_R(1)-coordinate_D(1))+sqr(coordinate_R(2)-coordinate_D(2)));
		Gamma_RD(symbol_ct) = pow(d_RD,-1.0*gamma_RD)*inv_dB(Gain_BF_dB/2.0)*inv_dB(PL0_dB);
		//update AoA_move
		double AoA_mov = atan((coordinate_R(1)-coordinate_D(1))/(coordinate_R(0)-coordinate_D_x(symbol_ct)));
		//update AoD
		double theta = acos((coordinate_D(2)-coordinate_R(2))/d_RD);
		double phi = atan((coordinate_D(1)-coordinate_R(1))/(coordinate_D_x(symbol_ct)-coordinate_R(0)));
		for(int m_y=0; m_y<M_RIS_y; m_y++) {
			for(int m_z=0; m_z<M_RIS_z; m_z++) {
				int m_ct = m_y*M_RIS_z + m_z;
				h_RD_LoS(m_ct,symbol_ct) = sqrt(Gamma_RD(symbol_ct)*K_RD/(K_RD+1))*exp(j*2*pi*symbol_ct*fd_RD*cos(AoA_mov))*exp(-j*pi*(m_y*sin(theta)*cos(phi)-m_z*sin(phi)));
				h_RD(m_ct,symbol_ct) = h_RD_LoS(m_ct,symbol_ct) + sqrt(Gamma_RD(symbol_ct)/(K_RD+1))*rayleigh_channels_RD(m_ct,symbol_ct);
				h_SRD(m_ct,symbol_ct) = h_SR(m_ct,symbol_ct)*h_RD(m_ct,symbol_ct);
			}
		}
	}

	cvec h_equi=zeros_c(total_symbols), h_equi_hat=zeros_c(total_symbols), y_all(total_symbols), v_all = N0*randn_c(total_symbols), h_SD_hat=zeros_c(total_symbols), N0_SD=zeros_c(total_symbols);
	cmat h_SRD_hat = zeros_c(M_RIS,total_symbols), alpha_RIS=zeros_c(M_RIS,total_symbols);
	for(int frame_ct=0; frame_ct<(N_w-1); frame_ct++) {
		y_all(frame_ct*N_f) = h_SD(frame_ct*N_f) + v_all(frame_ct*N_f);
		for(int m_ct=0; m_ct<M_RIS; m_ct++)
			y_all(frame_ct*N_f+1+m_ct) = h_SRD(m_ct,frame_ct*N_f+1+m_ct) + v_all(frame_ct*N_f+1+m_ct);
	}
	for(int frame_ct=(N_w-1); frame_ct<CSI_frames; frame_ct++) {
		y_all(frame_ct*N_f) = h_SD(frame_ct*N_f) + v_all(frame_ct*N_f);
		for(int m_ct=0; m_ct<M_RIS; m_ct++)
			y_all(frame_ct*N_f+1+m_ct) = h_SD(frame_ct*N_f+1+m_ct) + h_SRD(m_ct,frame_ct*N_f+1+m_ct) + v_all(frame_ct*N_f+1+m_ct);
		cmat C_SD(N_w,N_w);
		for(int i_ct=0; i_ct<N_w; i_ct++) {
			for(int j_ct=0; j_ct<N_w; j_ct++) {
				int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f;
				int n_index = (frame_ct-(N_w-1)+j_ct)*N_f;
				C_SD(i_ct,j_ct) = h_SD_LoS(n_index_hat)*conj(h_SD_LoS(n_index)) + (sqrt(Gamma_SD(n_index_hat)*Gamma_SD(n_index))/(1+K_SD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SD);
			}
			C_SD = C_SD + N0*eye_c(N_w);
		}
		cmat C_SD_inv = inv(C_SD);
		for(int m_ct=0; m_ct<M_RIS; m_ct++) {
			cmat e_SD(N_w,1);
			for(int i_ct=0; i_ct<N_w; i_ct++) {
				int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f;
				int n_index = frame_ct*N_f+1+m_ct;
				e_SD(i_ct) = h_SD_LoS(n_index_hat)*conj(h_SD_LoS(n_index)) + (sqrt(Gamma_SD(n_index_hat)*Gamma_SD(n_index))/(1+K_SD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SD);
			}
			cmat w_SD = conj(C_SD_inv*e_SD);
			for(int i_ct=0; i_ct<N_w; i_ct++)
				h_SD_hat(frame_ct*N_f+1+m_ct) = h_SD_hat(frame_ct*N_f+1+m_ct) + w_SD(i_ct)*y_all((frame_ct-(N_w-1)+i_ct)*N_f);
			y_all(frame_ct*N_f+1+m_ct) = y_all(frame_ct*N_f+1+m_ct) - h_SD_hat(frame_ct*N_f+1+m_ct);
//			cmat temp = hermitian_transpose(e_SD)*C_SD_inv*e_SD;
//			N0_SD(frame_ct*N_f+1+m_ct) = Gamma_SD(frame_ct*N_f+1+m_ct) - real(temp(0));
		}


		Array<cmat> C_SRD_inv(M_RIS);
		for(int m_ct=0; m_ct<M_RIS; m_ct++) {
			cmat C_SRD(N_w,N_w), N0_SD_temp = zeros_c(N_w,N_w);
			for(int i_ct=0; i_ct<N_w; i_ct++) {
				for(int j_ct=0; j_ct<N_w; j_ct++) {
					int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1;
					int n_index = (frame_ct-(N_w-1)+j_ct)*N_f+m_ct+1;
					C_SRD(i_ct,j_ct) = h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index));
					C_SRD(i_ct,j_ct) = C_SRD(i_ct,j_ct) + h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD);
					C_SRD(i_ct,j_ct) = C_SRD(i_ct,j_ct) + h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index))*(sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
					C_SRD(i_ct,j_ct) = C_SRD(i_ct,j_ct) + (sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD)*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
				}
				N0_SD_temp(i_ct,i_ct) = N0_SD((frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1);
			}
			C_SRD = C_SRD + N0_SD_temp + N0*eye_c(N_w);
			C_SRD_inv(m_ct) = inv(C_SRD);
		}
		for(int symbol_ct=0; symbol_ct<data_symbols_f; symbol_ct++) {
			cmat e_SD(N_w,1);
			for(int i_ct=0; i_ct<N_w; i_ct++) {
				int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f;
				int n_index = frame_ct*N_f+symbol_ct+M_RIS+1;
				e_SD(i_ct) = h_SD_LoS(n_index_hat)*conj(h_SD_LoS(n_index)) + (sqrt(Gamma_SD(n_index_hat)*Gamma_SD(n_index))/(1+K_SD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SD);
			}
			cmat w_SD = conj(C_SD_inv*e_SD);
			for(int i_ct=0; i_ct<N_w; i_ct++)
				h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1) = h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1) + w_SD(i_ct)*y_all((frame_ct-(N_w-1)+i_ct)*N_f);

			for(int m_ct=0; m_ct<M_RIS; m_ct++) {
				cmat e_SRD(N_w,1);
				for(int i_ct=0; i_ct<N_w; i_ct++) {
					int n_index_hat = (frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1;
					int n_index = frame_ct*N_f+symbol_ct+M_RIS+1;
					e_SRD(i_ct) = h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index));
					e_SRD(i_ct) = e_SRD(i_ct) + h_SR_LoS(n_index_hat)*conj(h_SR_LoS(n_index))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD);
					e_SRD(i_ct) = e_SRD(i_ct) + h_RD_LoS(n_index_hat)*conj(h_RD_LoS(n_index))*(sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
					e_SRD(i_ct) = e_SRD(i_ct) + (sqrt(Gamma_SR(n_index_hat)*Gamma_SR(n_index))/(1+K_SR))*(sqrt(Gamma_RD(n_index_hat)*Gamma_RD(n_index))/(1+K_RD))*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_RD)*besselj(0,2*pi*abs(n_index_hat-n_index)*fd_SR);
				}
				cmat w_SRD_m = conj(C_SRD_inv(m_ct)*e_SRD);
				for(int i_ct=0; i_ct<N_w; i_ct++)
					h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1) = h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1) + w_SRD_m(i_ct)*y_all((frame_ct-(N_w-1)+i_ct)*N_f+m_ct+1);

				alpha_RIS(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1) = h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1)*conj(h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1))/(abs(h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1))*abs(h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1)));
				h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) + alpha_RIS(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1)*h_SRD(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1);
				h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) + alpha_RIS(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1)*h_SRD_hat(m_ct,frame_ct*N_f+symbol_ct+M_RIS+1);
			}
			h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi(frame_ct*N_f+symbol_ct+M_RIS+1) + h_SD(frame_ct*N_f+symbol_ct+M_RIS+1);
			h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1) + h_SD_hat(frame_ct*N_f+symbol_ct+M_RIS+1);
			y_all(frame_ct*N_f+symbol_ct+M_RIS+1) = h_equi(frame_ct*N_f+symbol_ct+M_RIS+1)*s_tx(frame_ct*N_f+M_RIS+1+symbol_ct) + v_all(frame_ct*N_f+symbol_ct+M_RIS+1);
			complex<double> z = y_all(frame_ct*N_f+symbol_ct+M_RIS+1)*conj(h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1))/sqr(abs(h_equi_hat(frame_ct*N_f+symbol_ct+M_RIS+1)));
			int index_hat = PSK_QAM_Dem(z);
			for(int bit_ct=0; bit_ct<BPS; bit_ct++)
				b_hat((frame_ct-(N_w-1))*data_symbols_f*BPS+symbol_ct*BPS+bit_ct)=Symbol_Mapping_Bin(index_hat,bit_ct);
		}

//cout<<h_equi.mid(frame_ct*N_f+M_RIS+1,10)<<endl;
//cout<<h_equi_hat.mid(frame_ct*N_f+M_RIS+1,10)<<endl;
	}

	return b_hat;
}

int RIS_Ricean::PSK_QAM_Dem(const complex<double> z)
{
	int modulation_index = 0;

	if(modulation_type==MPSK)
		modulation_index = MPSK_Dem(z);
	else if(modulation_type==MQAM) {
		if(qam_type==Square)
			modulation_index = Square_MQAM_Dem(z);
		else if(qam_type==Star)
			modulation_index = Star_MQAM_Dem(z);
	}

	return modulation_index;
}

int RIS_Ricean::MPSK_Dem(const complex<double> z)
{
	int modulation_index_gray = round_i((constellation_points/(2.0*pi))*arg(z));
	int modulation_index_gray_nor = (int) rem(rem(1.0*modulation_index_gray,constellation_points)+constellation_points,constellation_points);
	int modulation_index = gray_code(modulation_index_gray_nor);

	return modulation_index;
}

int RIS_Ricean::Square_MQAM_Dem(const complex<double> z)
{
	int modulation_index_gray_real = round_i((constellation_points_QAM_real-1-beta_sqrt*real(z))/2.0);
	if(modulation_index_gray_real<0)
		modulation_index_gray_real = 0;
	else if(modulation_index_gray_real>(constellation_points_QAM_real-1))
		modulation_index_gray_real=(constellation_points_QAM_real-1);

	int modulation_index_gray_imag = round_i((constellation_points_QAM_imag-1-beta_sqrt*imag(z))/2.0);
	if(modulation_index_gray_imag<0)
		modulation_index_gray_imag = 0;
	else if(modulation_index_gray_imag>(constellation_points_QAM_imag-1))
		modulation_index_gray_imag=(constellation_points_QAM_imag-1);

	int modulation_index = gray_code(modulation_index_gray_real) + constellation_points_QAM_real*gray_code(modulation_index_gray_imag);

	return modulation_index;
}

int RIS_Ricean::Star_MQAM_Dem(const complex<double> z)
{
	int phase_index_gray = round_i((constellation_points_P/(2.0*pi))*arg(z));
	int phase_index_gray_nor = (int) rem(rem(1.0*phase_index_gray,constellation_points_P)+constellation_points_P,constellation_points_P);
	int phase_index = gray_code(phase_index_gray_nor);

	double metric_amp_min = 1e10;
	int amp_index = 0;
	for(int amp_ct=0; amp_ct<constellation_points_A; amp_ct++) {
		double metric_amp_next = sqr(Amplitude_Set(amp_ct))-2*Amplitude_Set(amp_ct)*real(conj(Phase_Set(phase_index))*z);
		if(metric_amp_next<metric_amp_min) {
			metric_amp_min = metric_amp_next;
			amp_index = amp_ct;
		}
	}

	int modulation_index = phase_index*constellation_points_A+amp_index;

	return modulation_index;
}


