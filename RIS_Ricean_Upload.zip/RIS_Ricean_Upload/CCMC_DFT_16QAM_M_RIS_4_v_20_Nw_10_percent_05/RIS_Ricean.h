#include<itpp/itcomm.h> 
#include <itpp/itbase.h>
#include <itpp/base/mat.h>
#include <iostream>
#include <fstream>
#include <itpp/comm/modulator.h>

using namespace itpp;
using namespace std;

typedef enum
{
	//employing PSK modulation scheme
	MPSK,
	//employing PAM modulation scheme
	MQAM
}ModulationType; 

typedef enum
{
	Square,
	Cross,
	Star
}QAM_Type;

class RIS_Ricean {
	public:
		int BPS, constellation_points;
		bmat Symbol_Mapping_Bin;
		cvec Symbol_Set, Symbol_Set_rotate;
		ModulationType modulation_type;
		QAM_Type qam_type;
		PSK psk;
		QAM qam;
		PAM_c qam_real, qam_imag;
		cmat DFT_Matrix, DFT_Matrix_inv;

		//Parameters for reduced-complexity detection
		int constellation_points_QAM_real, constellation_points_QAM_imag;
		int a_i_length_real, a_i_length_imag, a_i_length;
		bmat Symbol_Mapping_Bin_Magn, Symbol_Mapping_Bin_Magn_real, Symbol_Mapping_Bin_Magn_imag;
		vec a_i_real, a_i_imag, a_i;

		//Parameters for Star QAM
		int BPS_A, BPS_P, constellation_points_A, constellation_points_P;
		double beta, beta_sqrt;	//the ratio of outer ring radius divided by the inner ring radius
		double alpha;	//the normalisation factor
		bmat Symbol_Mapping_Bin_A, Symbol_Mapping_Bin_P;  //Mapping Set of binary bits, size=[2^BPS, BPS] for Symbol_Bin
		cvec Phase_Set, Phase_Set_rotate;
		vec Amplitude_Set;

		complex<double> j, phase_rotate;

		int M_RIS;
		double v_speed, f_c, f_s, lambda_c, fd_SD, fd_SR, fd_RD, K_SD_dB, K_SR_dB, K_RD_dB, K_SD, K_SR, K_RD, gamma_SD, gamma_SR, gamma_RD, Gain_BF_dB, PL0_dB;
		vec coordinate_S, coordinate_R, coordinate_D;

		RIS_Ricean(const int in_BPS, const int in_M_RIS);
		RIS_Ricean(const int in_BPS, const int in_M_RIS, const QAM_Type in_qam_type);
		RIS_Ricean(const int in_BPS, const int in_M_RIS, const int in_constellation_points_A, const double in_alpha);
		void Set_Modulation();
		void Set_Location(const vec in_coordinate_S, const vec in_coordinate_R, const vec in_coordinate_D);
		void Set_Freq(const double in_f_c, const double in_f_s, const double in_v_speed);
		void Set_K_Ricean(const double in_K_SD_dB, const double in_K_SR_dB, const double in_K_RD_dB);
		void Set_PL(const double in_gamma_SD, const double in_gamma_SR, const double in_gamma_RD, const double in_Gain_BF_dB, const double in_PL0_dB);
		void Display_Gamma();

		bvec RIS_Ricean_Perfect_CSI(const bvec b, const double N0);
		double CCMC_RIS_Ricean_Perfect_CSI(const int data_symbols, const double N0);
		double DCMC_RIS_Ricean_Perfect_CSI(const int data_symbols, const double N0);

		bvec RIS_Ricean_ONOFF_CSI(const bvec b, const double N0, const int N_f);
		void MSE_RIS_Ricean_ONOFF_CSI(const int data_symbols, const double N0, const int N_f, double &MSE_SD, double &MSE_SRD, double &MSE_AV);
		double NMSE_RIS_Ricean_ONOFF_CSI(const int data_symbols, const double N0, const int N_f);
		double CCMC_RIS_Ricean_ONOFF_CSI(const int data_symbols, const double N0, const int N_f);
		double DCMC_RIS_Ricean_ONOFF_CSI(const int data_symbols, const double N0, const int N_f);

		bvec RIS_Ricean_DFT_CSI(const bvec b, const double N0, const int N_f);
		void MSE_RIS_Ricean_DFT_CSI(const int data_symbols, const double N0, const int N_f, double &MSE_SD, double &MSE_SRD, double &MSE_AV);
		double NMSE_RIS_Ricean_DFT_CSI(const int data_symbols, const double N0, const int N_f);
		double CCMC_RIS_Ricean_DFT_CSI(const int data_symbols, const double N0, const int N_f);
		double DCMC_RIS_Ricean_DFT_CSI(const int data_symbols, const double N0, const int N_f);

		bvec RIS_Ricean_MMSE_CSI(const bvec b, const double N0, const int N_f, const int N_w);
		bvec RIS_Ricean_MMSE_CSI2(const bvec b, const double N0, const int N_f, const int N_w);
		void MSE_RIS_Ricean_MMSE_CSI(const int data_symbols, const double N0, const int N_f, const int N_w, double &MSE_SD, double &MSE_SRD, double &MSE_AV);
		double NMSE_RIS_Ricean_MMSE_CSI(const int data_symbols, const double N0, const int N_f, const int N_w);
		double CCMC_RIS_Ricean_MMSE_CSI(const int data_symbols, const double N0, const int N_f, const int N_w);
		double DCMC_RIS_Ricean_MMSE_CSI(const int data_symbols, const double N0, const int N_f, const int N_w);

		int PSK_QAM_Dem(const complex<double> z);
		int MPSK_Dem(const complex<double> z);
		int Square_MQAM_Dem(const complex<double> z);
		int Star_MQAM_Dem(const complex<double> z);
};

