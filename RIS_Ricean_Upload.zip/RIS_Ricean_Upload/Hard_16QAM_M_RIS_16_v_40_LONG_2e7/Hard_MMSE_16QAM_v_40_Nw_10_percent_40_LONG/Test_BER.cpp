#include <itpp/itbase.h>
#include<itpp/itcomm.h> 
#include "convert.h"
#include "RIS_Ricean_SD.h"

using namespace itpp;

using std::cout;
using std::endl;

int main()
{
	Real_Timer tt;
	tt.tic();
	RNG_randomize();

	int BPS = 4, constellation_points = (int) pow2(BPS);
	//Employing PSK
//	RIS_Ricean_SD ris(BPS);
	//Emloying QAM
 	QAM_Type qam_type = Square;
 	RIS_Ricean_SD ris(BPS, qam_type);
	//Employing Star QAM
// 	double alpha = 2;
// 	int constellation_points_A = 2;
//	RIS_Ricean_SD ris(BPS, constellation_points_A, alpha);

	vec coordinate_S = "0 0 0";
	vec coordinate_D = "290 -10 0";
	ris.Set_Location(coordinate_S,coordinate_D);
	vec f_c_can = "8.06e8 1.4745e9 2.593e9 4.7e9 2.5875e10 3.85e10";
	int f_c_mod = 2;
	double f_s = 100000, v_speed = 40;
	ris.Set_Freq(f_c_can(f_c_mod),f_s,v_speed);
	double K_SD_dB = -6.0;
	ris.Set_K_Ricean(K_SD_dB);
	double gamma_SD = 3.8, Gain_BF_dB = 0, PL0_dB = -30;
	ris.Set_PL(gamma_SD, Gain_BF_dB, PL0_dB);
cout<<ris.fd_SD<<endl;

	double pilot_percent = 0.40;
	int N_f = (int) 1.0/pilot_percent, N_w=10;
	pilot_percent=1.0/N_f;
//cout<<N_f<<" "<<pilot_percent<<endl;

	int frame_length = N_f*BPS, frame_length_data = (N_f-1)*BPS, frames = (int) 5e6;
	vec SNR = "50.0:5.0:200.0", EbN0 = SNR - 10*log10(BPS*(1-pilot_percent));
//cout<<frame_length<<" "<<frame_length_data<<endl;
cout<<frame_length_data*frames<<endl;

	double noise_sen = -124;
	vec PtdBm = SNR + noise_sen + Gain_BF_dB;

	vec ber = zeros(SNR.length());
	BERC berc;
	for(int frame_ct=0; frame_ct<frames; frame_ct++) {
		for(int SNR_ct=0; SNR_ct<SNR.length(); SNR_ct++) {
			bvec b = randb(frame_length_data);
			double N0 = 1.0/inv_dB(SNR(SNR_ct));
			bvec b_hat = ris.RIS_Ricean_SD_MMSE_CSI(b, N0, N_f, N_w);
			berc.clear();
			berc.count(b, b_hat);
			ber(SNR_ct) = ber(SNR_ct) + berc.get_errorrate();
			cout<<"MMSE: Frame "<<frame_ct+1<<", pilot_percent="<<pilot_percent<<", N_f="<<N_f<<", R="<<BPS*(1-pilot_percent)<<", v="<<v_speed<<": SNR="<<SNR(SNR_ct)<<"dB, EbN0="<<EbN0(SNR_ct)<<"dB, PtdBm="<<PtdBm(SNR_ct)<<"dB: ber="<<berc.get_errorrate()<<endl;
		}
	}
	ber = ber/frames;


	FILE  *fp1, *fp2, *fp3;
	string ber_name1 = "Hard_RIS_Ricean_SD_MMSE_CSI_BPS_"+stringify(BPS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_Nw_"+stringify(N_w)+"_K_SD_"+stringify(K_SD_dB)+"_gamma_SD_"+stringify(gamma_SD)+"_PL0_"+stringify(PL0_dB)+"_LONG_SNR.dat";
	string ber_name2 = "Hard_RIS_Ricean_SD_MMSE_CSI_BPS_"+stringify(BPS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_Nw_"+stringify(N_w)+"_K_SD_"+stringify(K_SD_dB)+"_gamma_SD_"+stringify(gamma_SD)+"_PL0_"+stringify(PL0_dB)+"_LONG_EbN0.dat";
	string ber_name3 = "Hard_RIS_Ricean_SD_MMSE_CSI_BPS_"+stringify(BPS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_Nw_"+stringify(N_w)+"_K_SD_"+stringify(K_SD_dB)+"_gamma_SD_"+stringify(gamma_SD)+"_PL0_"+stringify(PL0_dB)+"_LONG_PtdBm.dat";
	const char *ber_file_name1, *ber_file_name2, *ber_file_name3;
	ber_file_name1 = &ber_name1[0];
	ber_file_name2 = &ber_name2[0];
	ber_file_name3 = &ber_name3[0];
	fp1=fopen(ber_file_name1,"w");
	fp2=fopen(ber_file_name2,"w");
	fp3=fopen(ber_file_name3,"w");

	for(int SNR_ct=0; SNR_ct<SNR.length(); SNR_ct++) {
		cout<<"MMSE: pilot_percent="<<pilot_percent<<", N_f="<<N_f<<", R="<<BPS*(1-pilot_percent)<<", v="<<v_speed<<": SNR="<<SNR(SNR_ct)<<"dB, EbN0="<<EbN0(SNR_ct)<<"dB, PtdBm="<<PtdBm(SNR_ct)<<"dB: ber="<<ber(SNR_ct)<<endl;
		fprintf(fp1,"%f %e\n",SNR(SNR_ct),ber(SNR_ct));
		fprintf(fp2,"%f %e\n",EbN0(SNR_ct),ber(SNR_ct));
		fprintf(fp3,"%f %e\n",PtdBm(SNR_ct),ber(SNR_ct));
		if(ber(SNR_ct)<1e-6)
			break;
	}

	fclose(fp1);
	fclose(fp2);
	fclose(fp3);


	// Print the elapsed time
	tt.toc_print();
	return 0;
}
