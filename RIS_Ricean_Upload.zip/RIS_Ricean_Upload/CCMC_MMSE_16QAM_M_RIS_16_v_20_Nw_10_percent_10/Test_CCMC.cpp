#include <itpp/itbase.h>
#include<itpp/itcomm.h> 
#include "convert.h"
#include "RIS_Ricean.h"

using namespace itpp;

using std::cout;
using std::endl;

int main()
{
	Real_Timer tt;
	tt.tic();
	RNG_randomize();

	int BPS = 4, M_RIS = 16, constellation_points = (int) pow2(BPS);
	//Employing PSK
//	RIS_Ricean ris(BPS, M_RIS);
	//Emloying QAM
 	QAM_Type qam_type = Square;
 	RIS_Ricean ris(BPS, M_RIS, qam_type);
	//Employing Star QAM
// 	double alpha = 2;
// 	int constellation_points_A = 2;
//	RIS_Ricean ris(BPS, M_RIS, constellation_points_A, alpha);

	vec coordinate_S = "0 0 0";
	vec coordinate_R = "300 10 0";
	vec coordinate_D = "290 -10 0";
	ris.Set_Location(coordinate_S,coordinate_R,coordinate_D);
	vec f_c_can = "8.06e8 1.4745e9 2.593e9 4.7e9 2.5875e10 3.85e10";
	int f_c_mod = 2;
	double f_s = 100000, v_speed = 20;
	ris.Set_Freq(f_c_can(f_c_mod),f_s,v_speed);
	double K_SD_dB = -6.0, K_SR_dB = 0.0, K_RD_dB = 0.0;
	ris.Set_K_Ricean(K_SD_dB,K_SR_dB,K_RD_dB);
	double gamma_SD = 3.8, gamma_SR = 2.0, gamma_RD = 2.0, Gain_BF_dB = 0, PL0_dB = -30;
	ris.Set_PL(gamma_SD, gamma_SR, gamma_RD, Gain_BF_dB, PL0_dB);
cout<<ris.fd_SD<<endl;

	double pilot_percent = 0.10;
	int N_f = (int) (M_RIS+1)/pilot_percent, N_w=10;
	pilot_percent=(1.0+M_RIS)/N_f;
//cout<<N_f<<" "<<pilot_percent<<endl;

	int frame_length = N_f*BPS, frame_length_data = (N_f-(M_RIS+1))*BPS, frames = 6800;
	vec SNR = "50.0:4.0:150.0", EbN0 = SNR - 10*log10(BPS*(1-pilot_percent));
//cout<<frame_length<<" "<<frame_length_data<<endl;
cout<<frame_length_data*frames/BPS<<endl;

	double noise_sen = -104;
	vec PtdBm = SNR + noise_sen + Gain_BF_dB;

	vec CCMC_perfect = zeros(SNR.length()), CCMC_ONOFF = zeros(SNR.length()), CCMC_DFT = zeros(SNR.length()), CCMC_MMSE = zeros(SNR.length());
	for(int frame_ct=0; frame_ct<frames; frame_ct++) {
		for(int SNR_ct=0; SNR_ct<SNR.length(); SNR_ct++) {
			double N0 = 1.0/inv_dB(SNR(SNR_ct));
			cout<<"Frame "<<frame_ct+1<<", pilot_percent="<<pilot_percent<<", R="<<BPS*(1-pilot_percent)<<", v="<<v_speed<<": SNR="<<SNR(SNR_ct)<<"dB, EbN0="<<EbN0(SNR_ct)<<"dB, PtdBm="<<PtdBm(SNR_ct)<<"dB:"<<endl;
			double CCMC_perfect_next = ris.CCMC_RIS_Ricean_Perfect_CSI(frame_length_data/BPS, N0);
			cout<<"Perfect: CCMC = "<<CCMC_perfect_next<<endl;
			CCMC_perfect(SNR_ct) = CCMC_perfect(SNR_ct) + CCMC_perfect_next;
			double CCMC_ONOFF_next = (1.0-pilot_percent)*ris.CCMC_RIS_Ricean_ONOFF_CSI(frame_length_data/BPS, N0, N_f);
			cout<<"ONOFF  : CCMC = "<<CCMC_ONOFF_next<<endl;
			CCMC_ONOFF(SNR_ct) = CCMC_ONOFF(SNR_ct) + CCMC_ONOFF_next;
			double CCMC_DFT_next = (1.0-pilot_percent)*ris.CCMC_RIS_Ricean_DFT_CSI(frame_length_data/BPS, N0, N_f);
			cout<<"DFT    : CCMC = "<<CCMC_DFT_next<<endl;
			CCMC_DFT(SNR_ct) = CCMC_DFT(SNR_ct) + CCMC_DFT_next;
			double CCMC_MMSE_next = (1.0-pilot_percent)*ris.CCMC_RIS_Ricean_MMSE_CSI(frame_length_data/BPS, N0, N_f, N_w);
			cout<<"MMSE   : CCMC = "<<CCMC_MMSE_next<<endl;
			CCMC_MMSE(SNR_ct) = CCMC_MMSE(SNR_ct) + CCMC_MMSE_next;
		}
	}
	CCMC_perfect = CCMC_perfect/frames;
	CCMC_ONOFF = CCMC_ONOFF/frames;
	CCMC_DFT = CCMC_DFT/frames;
	CCMC_MMSE = CCMC_MMSE/frames;


	FILE  *fp1, *fp2, *fp3, *fp4, *fp5, *fp6, *fp7, *fp8;
	string ber_name1 = "Hard_RIS_Ricean_Perfect_CSI_BPS_"+stringify(BPS)+"_M_"+stringify(M_RIS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_SNR.dat";
	string ber_name2 = "Hard_RIS_Ricean_Perfect_CSI_BPS_"+stringify(BPS)+"_M_"+stringify(M_RIS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_EbN0.dat";
	string ber_name3 = "Hard_RIS_Ricean_ONOFF_CSI_BPS_"+stringify(BPS)+"_M_"+stringify(M_RIS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_SNR.dat";
	string ber_name4 = "Hard_RIS_Ricean_ONOFF_CSI_BPS_"+stringify(BPS)+"_M_"+stringify(M_RIS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_EbN0.dat";
	string ber_name5 = "Hard_RIS_Ricean_DFT_CSI_BPS_"+stringify(BPS)+"_M_"+stringify(M_RIS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_SNR.dat";
	string ber_name6 = "Hard_RIS_Ricean_DFT_CSI_BPS_"+stringify(BPS)+"_M_"+stringify(M_RIS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_EbN0.dat";
	string ber_name7 = "Hard_RIS_Ricean_MMSE_CSI_BPS_"+stringify(BPS)+"_M_"+stringify(M_RIS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_Nw_"+stringify(N_w)+"_SNR.dat";
	string ber_name8 = "Hard_RIS_Ricean_MMSE_CSI_BPS_"+stringify(BPS)+"_M_"+stringify(M_RIS)+"_fc_"+stringify(f_c_mod)+"_v_"+stringify(round_i(v_speed))+"_pilot_percent_"+stringify(round_i(pilot_percent*100))+"_Nw_"+stringify(N_w)+"_EbN0.dat";
	const char *ber_file_name1, *ber_file_name2, *ber_file_name3, *ber_file_name4, *ber_file_name5, *ber_file_name6, *ber_file_name7, *ber_file_name8;
	ber_file_name1 = &ber_name1[0];
	ber_file_name2 = &ber_name2[0];
	ber_file_name3 = &ber_name3[0];
	ber_file_name4 = &ber_name4[0];
	ber_file_name5 = &ber_name5[0];
	ber_file_name6 = &ber_name6[0];
	ber_file_name7 = &ber_name7[0];
	ber_file_name8 = &ber_name8[0];
	fp1=fopen(ber_file_name1,"w");
	fp2=fopen(ber_file_name2,"w");
	fp3=fopen(ber_file_name3,"w");
	fp4=fopen(ber_file_name4,"w");
	fp5=fopen(ber_file_name5,"w");
	fp6=fopen(ber_file_name6,"w");
	fp7=fopen(ber_file_name7,"w");
	fp8=fopen(ber_file_name8,"w");

	for(int SNR_ct=0; SNR_ct<SNR.length(); SNR_ct++) {
		cout<<"pilot_percent="<<pilot_percent<<", R="<<BPS*(1-pilot_percent)<<", v="<<v_speed<<": SNR="<<SNR(SNR_ct)<<"dB, EbN0="<<EbN0(SNR_ct)<<"dB, PtdBm="<<PtdBm(SNR_ct)<<"dB:"<<endl;
		cout<<"Perfect: CCMC = "<<CCMC_perfect(SNR_ct)<<endl;
		cout<<"ONOFF  : CCMC = "<<CCMC_ONOFF(SNR_ct)<<endl;
		cout<<"DFT    : CCMC = "<<CCMC_DFT(SNR_ct)<<endl;
		cout<<"MMSE   : CCMC = "<<CCMC_MMSE(SNR_ct)<<endl;
		fprintf(fp1,"%f %f\n",SNR(SNR_ct),CCMC_perfect(SNR_ct));
		fprintf(fp2,"%f %f\n",EbN0(SNR_ct),CCMC_perfect(SNR_ct));
		fprintf(fp3,"%f %f\n",SNR(SNR_ct),CCMC_ONOFF(SNR_ct));
		fprintf(fp4,"%f %f\n",EbN0(SNR_ct),CCMC_ONOFF(SNR_ct));
		fprintf(fp5,"%f %f\n",SNR(SNR_ct),CCMC_DFT(SNR_ct));
		fprintf(fp6,"%f %f\n",EbN0(SNR_ct),CCMC_DFT(SNR_ct));
		fprintf(fp7,"%f %f\n",SNR(SNR_ct),CCMC_MMSE(SNR_ct));
		fprintf(fp8,"%f %f\n",EbN0(SNR_ct),CCMC_MMSE(SNR_ct));
	}

	fclose(fp1);
	fclose(fp2);
	fclose(fp3);
	fclose(fp4);
	fclose(fp5);
	fclose(fp6);
	fclose(fp7);
	fclose(fp8);

	// Print the elapsed time
	tt.toc_print();
	return 0;
}
